# Jyotisha Corpus — Source-Grounded Vedic Astrology Knowledge Base

A research-grade, provenance-preserving corpus of Vedic astrology (Jyotisha): classical texts,
machine-verified extracted rules, and a reproducible acquisition pipeline. Every rule traces to a
chapter and verse; every source carries rights metadata and a sha256 hash.

Built from public-domain and open-access sources only. **This is a knowledge archive, not an
astrology chatbot** — the goal is the infrastructure an expert Jyotisha AI could be built from:
completeness, provenance, structure, school separation, and contradiction preservation over
summarization.

## What's in here

| Layer | Contents |
|---|---|
| `data/rules.json` | **199 extracted rules** — atomic (condition → interpretation), each with `source_quote` machine-verified as a verbatim substring of the held source text. Sources: Brihat Jataka (60), Jataka Parijata (60), Brihat Samhita (59), Phaladeepika (20). |
| `texts/`, `chunks/` | Clean text + semantic chunks for **10 verified public-domain texts** (pre-1929 editions): Brihat Samhita (Iyer 1884), Brihat Jataka (Iyer 1905, Rao 1919), Saravali (1907), Laghu Parashari (1900), Surya Siddhanta (Burgess 1860), Panchasiddhantika (1882 / Dvivedi 1889 / Thibaut 1889), Hindu Book of Astrology (1902). |
| `sources/sources-registry.json` | Full provenance ledger: **75 catalogued sources** (58 acquired), each with archive URL, rights reasoning, access status, file hashes, acquisition method/date. |
| `data/texts.json` | Text catalog with quality tiers (OK_ENGLISH / DEVANAGARI / ITX_TRANSLITERATED / MIXED), chapter counts, access status. |
| `data/software.json` | Catalog of 8 open-source Jyotisha calculation libraries (repos live upstream, not vendored). |
| `scripts/` | The full pipeline: discovery (archive.org + GitHub search), rights gating, acquisition, processing (clean text + chunks), varshaphala/monthly-timing computation (Swiss Ephemeris, Lahiri), quality audits. |
| `reports/` | Coverage report (honest numbers) + failed/excluded source report. |
| `SPEC.md` | The 75-section governing specification this corpus is built against. |

**Current numbers:** 75 records · 58 sources with files · 29.8M chars clean text (full local vault) · 1,099 chunks · 199 verified rules · 7 software repos cloned.

## Legal posture (summary — see `LEGAL.md`)

- This repo redistributes only **verified public-domain** texts (pre-1929 editions) and
  machine-extracted facts/short quotations.
- The full local vault includes ~40 `PD_IN_INDIA_LIKELY` items (pre-1960 Indian publications,
  flagged, not yet death-date-audited) — **not redistributed here**.
- 15 volunteer-transcribed Sanskrit texts from sanskritdocuments.org are used under their
  "personal study and research" terms — **metadata only in this repo**.
- 17 copyrighted works (Raman, Santhanam, Rath, Rao) are catalogued with metadata, never acquired.

## Reproduce the full corpus

The full 58-source vault is one command away — the registry knows every URL:

```bash
pip install pyswisseph   # for the varshaphala/timing scripts
python scripts/discovery/fetch_full_corpus.py   # downloads the non-redistributed sources from archive.org
```

The fetch script respects the registry's gate: it downloads `ACQUIRE`/`ACQUIRE_NOTE` items and
skips `CATALOG_ONLY` (copyright) items.

## Contributing

1. **Rules must be verbatim-anchored** — `source_quote` is a literal substring of the held text; no paraphrasing, no fabricated verses (see the extraction pattern in `SCHEMAS.md`).
2. **Schools are separate namespaces** — Parashari, Jaimini, Nadi, Bhrigu, Tajika, Prashna, Muhurta. Contradictions are recorded, never merged.
3. **Unknown > invented** — `UNKNOWN`/`UNCERTAIN`/`DISPUTED`/`TRADITIONALLY_ATTRIBUTED` are valid values.
4. **No piracy** — cracked software and paywalled content are refused and logged, not smuggled in.

## Roadmap

Tajika + Prashna acquisition (the two zero-coverage schools) · re-OCR of 5 mixed-quality scans ·
academic layer (history of Jyotisha papers) · vector search index · rule-extraction scale-up
(199 → 2,000+) · case studies (documented charts with sources).

## Credits

Text sources: Internet Archive (public scans), sanskritdocuments.org (volunteer-transcribed
Sanskrit), Digital Library of India. Calculation tooling: Swiss Ephemeris. All extraction and
verification performed by the corpus pipeline.

**License:** code MIT (see `LICENSE`); generated data CC BY 4.0 (see `DATA_LICENSE`); source
texts public domain where marked in the registry.
