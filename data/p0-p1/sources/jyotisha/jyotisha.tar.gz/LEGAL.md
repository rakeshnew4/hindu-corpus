# LEGAL — Provenance & Rights Posture

This file documents the copyright/access status of every layer in this repository and the
reasoning behind what is and isn't redistributed. It is the audit trail for the corpus's
"maximum legitimate coverage, not piracy" policy (SPEC §3).

## What is redistributed here (and why it's legal)

1. **Verified public-domain texts** (`texts/`, `chunks/`) — editions published before 1929 in the
   US or by authors long deceased: Iyer's Brihat Samhita (1884) and Brihat Jataka (1905),
   Burgess's Surya Siddhanta (1860), Saravali (1907), Laghu Parashari (1900), Rao's Brihat Jataka
   (1919), Panchasiddhantika editions (1882/1889), Hindu Book of Astrology (1902). Public domain
   in the US; redistributable without restriction.
2. **Extracted facts and short quotations** (`data/rules.json`) — atomic rule extractions with
   brief (1–3 sentence) verbatim quotations for scholarly compilation. Even where a source
   translation is not confirmed public domain (e.g. Phaladeepika 1950, Jataka Parijata 1932), the
   quoted passages are minimal and the records are transformative; full texts of these are NOT
   redistributed.
3. **Metadata** (`sources/sources-registry.json`, `data/texts.json`) — bibliographic facts,
   URLs, and rights assessments. Facts are not copyrightable.

## What is NOT redistributed (and why)

1. **`PD_IN_INDIA_LIKELY` items** — ~40 pre-1960 Indian publications (Sastri's Phaladeepika/Jataka
   Parijata editions, Mishra 1948, Venkateshwar 1933, Vimala/Sudha commentaries, Ashtakavarga
   1957, etc.) served openly by archive.org. India's copyright term is 60 years post-mortem;
   translator death dates are flagged but **not yet audited**. These are in the private vault,
   acquirable via `scripts/discovery/fetch_full_corpus.py` at the user's own risk assessment.
2. **sanskritdocuments.org volunteer texts** — 15 machine-readable Sanskrit files (incl. the full
   BPHS). The site's own header states texts are "prepared by volunteers… to be used for personal
   study and research." Redistribution would breach those terms. **Metadata + URLs only here.**
3. **Copyrighted works, catalogued only** — B.V. Raman (d. 1998; in copyright to ~2058),
   R. Santhanam (d. 2005; ~2065), Sanjay Rath, K.S. Charak, R.G. Rao, and others. Recorded in the
   registry with `CATALOG_ONLY`; never downloaded.
4. **Software** — the 8 calculation libraries are catalogued in `data/software.json` but live at
   their upstream repos (MIT/Apache/AGPL); AGPL code (PyJHora) is not vendored to avoid copyleft
   contamination of this corpus.
5. **Cracked software** — one item (Parashara Light crack) was refused and logged, not acquired.

## Known audit tasks

- Verify death dates for all `PD_IN_INDIA_LIKELY` authors (translators/commentators) to upgrade
  their status to verified PD or demote to catalog-only.
- Confirm sanskritdocuments.org redistribution terms with the site maintainers if full-text
  redistribution is ever desired.

## Policy

- Raw originals are immutable; every derivative layer references its raw source.
- No DRM bypass, no paywall evasion, no scraping of private systems.
- A missing fact is preferable to a fabricated fact (SPEC §47).
