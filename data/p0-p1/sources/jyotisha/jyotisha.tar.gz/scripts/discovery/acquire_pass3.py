#!/usr/bin/env python3
"""Acquisition pass 3: Brihat Samhita editions + BPHS commentaries from sanskritdocuments links."""
import json, os, time, urllib.request, urllib.parse, hashlib

UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"
MAX_MB = 130

ITEMS = [
    # (archive_id, source_id, note)
    ("brihatsamhitavarahamihirabruhatkernh.asiaticsociety1865_754_d", "TXT-brihat-samhita-kern1865",
     "Brihat Samhita, Kern 1865 Asiatic Society (Sanskrit w/ notes)"),
    ("brihatsamhitaenglishtranslationchidambaramiyerwithappendix1885_432_w", "TXT-brihat-samhita-iyer1885",
     "Brihat Samhita, Iyer trans. 1885 with appendix"),
    ("brihatsamhitawithhinditikabaldevprasadmishra1948khemraj_807_X", "TXT-brihat-samhita-mishra1948-hindi",
     "Brihat Samhita with Hindi tika, Baldev Prasad Mishra 1948 (Khemraj)"),
    ("in.ernet.dli.2015.408097", "TXT-brihatsamhita-dli1959", "Brihatsamhita, DLI 1959"),
    ("ShatpanchashikaVSSastri", "TXT-shatpanchasika-sastri", "Shatpanchasika, V.S. Sastri"),
    ("varahi-brihat-samhita-1933-lakshmi-venkateshwar-press", "TXT-brihat-samhita-venkateshwar1933",
     "Varahi Brihat Samhita 1933, Lakshmi Venkateshwar Press (PDF 1.2GB -> text layer)"),
    ("bmmv_brihat-parashar-hora-shastra-of-parashar-muni-with-sudha-commentary-by-pt.-dev-c", "TXT-bphs-sudha-kss220",
     "BPHS with Sudha commentary, Pt. Dev Chandra Jha, Kashi Sanskrit Series 220, Chaukhamba"),
    ("JvEo_brihat-samhita-of-bhattotpal-with-vimala-hindi-commentary-by-pt.-achyuta-nand-jh", "TXT-brihat-samhita-vimala-vol2",
     "Brihat Samhita w/ Bhattotpala + Vimala Hindi commentary, A.N. Jha, Vol 2"),
    ("dhSS_brihat-samhita-of-bhattotpal-with-vimala-hindi-commentary-by-pt.-achyuta-nand-jh", "TXT-brihat-samhita-vimala-vol1",
     "Brihat Samhita w/ Bhattotpala + Vimala Hindi commentary, A.N. Jha, Vol 1"),
    ("wg873", "TXT-bphs-sanskrit-2009print", "Brihat Parashar Hora Shastram, 2009 print of ancient Sanskrit text"),
    ("varahi-brihat-samhita-of-varahmihir-pandit-baldev-prasad-muradabad", "TXT-brihat-samhita-baldevprasad-hindi",
     "Varahi Brihat Samhita, Pandit Baldev Prasad Hindi (Muradabad), early 20th c"),
    ("Laghujatkam", "TXT-laghujataka", "Laghujatakam of Varahamihira (Varaha Mishra)"),
]
CATALOG_ONLY = [
    ("lPan_brihat-samhita-of-sri-varaha-mihira-part-2-with-bhattotpala-commentary-edited-by",
     "Dr. K.C. Dwivedi critical edition, 1996 (Sampurnanand Sanskrit University)"),
    ("ParasharaHoraSastra", "Compiled English ebook, unknown provenance (likely Santhanam-derived)"),
]

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def fsize(p):
    try: return int(p.get("size") or 0)
    except (TypeError, ValueError): return 0

def download(url, dest, max_mb=MAX_MB, attempts=4):
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as f:
                total = 0
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    total += len(chunk)
                    if total > max_mb * (1 << 20):
                        os.remove(tmp); return None, "too large"
                    f.write(chunk)
            os.replace(tmp, dest)
            return total, "ok"
        except Exception as e:
            if i == attempts - 1: return None, str(e)[:80]
            time.sleep(3 * (i + 1))
    return None, "unknown"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def main():
    reg = json.load(open("sources/sources-registry.json", encoding="utf-8"))
    have = {r["source_id"] for r in reg}
    added = []
    for ident, sid, note in ITEMS:
        if sid in have:
            print(f"[SKIP] {sid} already in registry"); continue
        outdir = os.path.join("raw", sid)
        os.makedirs(outdir, exist_ok=True)
        try:
            d = get(f"https://archive.org/metadata/{ident}")
        except Exception as e:
            print(f"[ERR] {sid}: {str(e)[:60]}"); continue
        files = d.get("files", [])
        def flat(v):
            if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
            return str(v or "")
        md = d.get("metadata", {})
        rec = {"archive_id": ident, "source_id": sid, "decision": "ACQUIRE_NOTE", "note": note,
               "title": flat(md.get("title"))[:100], "creator": flat(md.get("creator"))[:60],
               "rights": (md.get("rights") or "")[:100], "access_status": "PD_IN_INDIA_LIKELY",
               "reason": "pre-1960 Indian publication or ancient text in modern print; PD-in-India likely (verify)"}
        got = []
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        if djvu:
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(djvu[0]),
                             os.path.join(outdir, djvu[0]))
            if st == "ok": rec["text_file"] = djvu[0]; rec["text_bytes"] = n; got.append(djvu[0])
        pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
        pdf = None
        for p in sorted(pdfs, key=lambda p: -fsize(p)):
            if fsize(p) <= MAX_MB * (1 << 20): pdf = p; break
        if pdf:
            fn = pdf["name"]
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                             os.path.join(outdir, fn))
            if st == "ok":
                rec["pdf_file"] = fn; rec["pdf_bytes"] = n
                rec["file_hash"] = "sha256:" + sha256(os.path.join(outdir, fn))
                got.append(fn)
            else:
                rec["pdf_error"] = st
        elif pdfs:
            rec["pdf_error"] = f"largest pdf {max(fsize(p) for p in pdfs)//(1<<20)}MB > cap"
        rec["acquired_files"] = got
        rec["acquisition_date"] = "2026-08-31"
        rec["acquisition_method"] = "archive.org direct download"
        reg.append(rec); added.append(rec)
        print(f"[{rec['decision']:12}] {sid:38} files={len(got)} {rec.get('pdf_error','')}")
        time.sleep(0.3)
    for ident, why in CATALOG_ONLY:
        if ident not in [r.get("archive_id") for r in reg]:
            reg.append({"archive_id": ident, "source_id": "TXT-" + ident[:36], "decision": "CATALOG_ONLY",
                        "reason": why, "access_status": "CATALOG_ONLY", "acquired_files": []})
            print(f"[CATALOG_ONLY] {ident[:44]}")
    json.dump(reg, open("sources/sources-registry.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"\nregistry: {len(reg)} records (+{len(added)} acquired)")

if __name__ == "__main__":
    main()
