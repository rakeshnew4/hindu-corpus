#!/usr/bin/env python3
"""Finalize decisions from inspect_review.py, re-run gate with word-boundary fix,
download newly-cleared items, rewrite registry."""
import json, re, time, urllib.request, urllib.parse, hashlib, os

UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"

OVERRIDES = {
    "hindubookofastro00bhakrich": ("ACQUIRE", "US copyright 1902 -> public domain (pre-1929)"),
    "SuryaSiddhantaTranslation": ("ACQUIRE", "Burgess translation 1860, PD; 1935 Gangooly edition notes"),
    "BrihatJataka2ndEd.ByVSubrahmanyaSastri": ("ACQUIRE_NOTE", "Sastri d.~1946 -> PD-in-India since 2006; scan imprint reads 2nd ed. (1929 orig.; OCR shows 1996 reprint)"),
    "Phaladeepika2ndEd.1950ByVSubrahmanyaSastri": ("ACQUIRE_NOTE", "pub 1950, Sastri d.~1946 -> PD-in-India since 2006"),
    "JatakaParijataVolIOfIIByVSubrahmanyaSastri": ("ACQUIRE_NOTE", "pub 1932-33 (V.B. Soobbiah & Sons), Sastri d.~1946 -> PD-in-India since 2006"),
    "JatakaParijata1932": ("ACQUIRE_NOTE", "pub 1932, Sastri d.~1946 -> PD-in-India since 2006 (was false-flagged as B.V. Raman)"),
    "Brihatsamhita": ("ACQUIRE_NOTE", "Sastri + M.R. Bhat translation, 1946 ed.; Sastri d.~1946 -> PD-in-India likely"),
    "muhurta-chintamani-kedar-datt-joshi": ("ACQUIRE_NOTE", "Kedar Datt Joshi Hindi vyakhya, early 20th c.; likely PD-in-India (verify death)"),
    "surya-siddhanta_202102": ("ACQUIRE_NOTE", "Sarvahitkari press Hindi Surya Siddhanta (19th c. text); OCR quality poor"),
    "SuryaSiddhanta_201311": ("ACQUIRE_NOTE", "Hindi commentary by Mahavir Prasad Dwivedi (d.1938) -> PD-in-India since 1998"),
    "brihat-parashara-hora-sastra": ("CATALOG_ONLY", "Santhanam translation (d. 2005), in copyright; seek Sanskrit BPHS elsewhere"),
    "Book11.HoraRatnam10NoOCR": ("CATALOG_ONLY", "Hora Ratnam trans. R. Santhanam (d. 2005), in copyright; no OCR"),
    "bhrigu-nandi-nadi": ("CATALOG_ONLY", "modern compilation by R.G. Rao (~1980s), in copyright; not an ancient text"),
    "jyotisha": ("DEFER", "Sanskrit DLI bundle, 12 PDFs, poor Devanagari OCR; per-file review in pass 2"),
}

MODERN = re.compile(r"\b(raman|santhanam|sanjay rath|charak|mishra|surkant|verma, o|rao, r|sharma, mahidhar)\b", re.I)

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def fsize(p):
    try: return int(p.get("size") or 0)
    except (TypeError, ValueError): return 0

def download(url, dest, max_mb=130, attempts=4):
    import time as _t
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=180) as r, open(tmp, "wb") as f:
                total = 0
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    total += len(chunk)
                    if total > max_mb * (1 << 20):
                        os.remove(tmp); return None, "too large"
                    f.write(chunk)
            os.replace(tmp, dest)
            return total, "ok"
        except Exception as e:
            if i == attempts - 1:
                return None, str(e)[:80]
            _t.sleep(3 * (i + 1))
    return None, "unknown"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def main():
    reg = json.load(open("sources/sources-registry.json", encoding="utf-8"))
    # populate from disk: files already downloaded in prior (crashed) runs
    for rec in reg:
        od = os.path.join("raw", rec["source_id"])
        if os.path.isdir(od):
            names = os.listdir(od)
            for n in names:
                if n.endswith("_djvu.txt") and not rec.get("text_file"):
                    rec["text_file"] = n
                elif n.lower().endswith(".pdf") and not rec.get("pdf_file"):
                    rec["pdf_file"] = n
    updated = 0
    for rec in reg:
        ident = rec["archive_id"]
        if ident in OVERRIDES:
            dec, why = OVERRIDES[ident]
            rec["decision"], rec["reason"] = dec, why
            rec["access_status"] = "PUBLIC_DOMAIN" if dec == "ACQUIRE" else (
                "PD_IN_INDIA_LIKELY" if dec == "ACQUIRE_NOTE" else
                "CATALOG_ONLY" if dec == "CATALOG_ONLY" else "DEFERRED")
        else:
            # word-boundary re-check for the mis-flagged Sastri items
            creator = (rec.get("creator") or "")
            if MODERN.search(creator) and rec.get("decision") == "CATALOG_ONLY":
                # only flip if reason was the modern-author false positive
                if rec.get("reason", "").startswith("modern author"):
                    rec["decision"] = "ACQUIRE_NOTE"
                    rec["reason"] = f"author {creator!r} is classical translator, not modern author; PD-in-India likely"
                    rec["access_status"] = "PD_IN_INDIA_LIKELY"
        # download missing files for cleared items (skip if already on disk)
        outdir = os.path.join("raw", rec["source_id"])
        want = [w for w in [rec.get("text_file"), rec.get("pdf_file")] if w]
        have = want and all(os.path.exists(os.path.join(outdir, w)) for w in want)
        if rec.get("decision") in ("ACQUIRE", "ACQUIRE_NOTE") and not have:
            outdir = os.path.join("raw", rec["source_id"])
            os.makedirs(outdir, exist_ok=True)
            try:
                d = get(f"https://archive.org/metadata/{ident}")
            except Exception as e:
                print(f"[ERR] {ident}: {e}"); continue
            files = d.get("files", [])
            djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
            pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
            got = []
            if djvu:
                fn = djvu[0]
                n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                                 os.path.join(outdir, fn))
                if st == "ok": rec["text_file"] = fn; rec["text_bytes"] = n; got.append(fn)
            pdf = None
            for p in sorted(pdfs, key=lambda p: -fsize(p)):
                if fsize(p) <= 130 * (1 << 20): pdf = p; break
            if pdf:
                fn = pdf["name"]
                n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                                 os.path.join(outdir, fn))
                if st == "ok":
                    rec["pdf_file"] = fn; rec["pdf_bytes"] = n
                    rec["file_hash"] = "sha256:" + sha256(os.path.join(outdir, fn))
                    got.append(fn)
            rec["acquired_files"] = got
            rec["acquisition_date"] = "2026-08-31"
            rec["acquisition_method"] = "archive.org direct download"
            print(f"[{rec['decision']:12}] {rec['source_id']:36} files={len(got)}")
            updated += 1
            time.sleep(0.2)
        else:
            print(f"[{rec['decision']:12}] {rec['source_id']:36} (registry kept)")
    with open("sources/sources-registry.json", "w", encoding="utf-8") as f:
        json.dump(reg, f, indent=1)
    print(f"updated {updated} records")

if __name__ == "__main__":
    main()
