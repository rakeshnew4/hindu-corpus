#!/usr/bin/env python3
"""Inspect REVIEW items: fetch description + djvu.txt head to identify edition/year."""
import json, time, urllib.request, urllib.parse, os

UA = {"User-Agent": "jyotisha-corpus/1.0"}
REVIEW = [
    "hindubookofastro00bhakrich", "SuryaSiddhantaTranslation",
    "BrihatJataka2ndEd.ByVSubrahmanyaSastri", "Phaladeepika2ndEd.1950ByVSubrahmanyaSastri",
    "JatakaParijataVolIOfIIByVSubrahmanyaSastri", "JatakaParijata1932",
    "Brihatsamhita", "jyotisha", "brihat-parashara-hora-sastra",
    "muhurta-chintamani-kedar-datt-joshi", "surya-siddhanta_202102",
    "SuryaSiddhanta_201311", "Book11.HoraRatnam10NoOCR", "bhrigu-nandi-nadi",
]

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

for ident in REVIEW:
    try:
        md = json.loads(get(f"https://archive.org/metadata/{ident}"))["metadata"]
        desc = (md.get("description") or "")[:200].replace("\n", " ")
        files = json.loads(get(f"https://archive.org/metadata/{ident}"))["files"]
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        head = ""
        if djvu:
            fn = djvu[0]
            txt = get("https://archive.org/download/" + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn), timeout=120)
            head = txt.decode("utf-8", "replace")[:500].replace("\n", " | ")
        print(f"===== {ident}")
        print(f"  title: {md.get('title','')[:90]}")
        print(f"  creator: {md.get('creator','')[:60]} | date: {md.get('date','')[:30]} | year: {md.get('year','')[:30]}")
        print(f"  desc: {desc[:180]}")
        print(f"  head: {head[:420]}")
    except Exception as e:
        print(f"===== {ident}\n  ERROR: {str(e)[:100]}")
    time.sleep(0.3)
