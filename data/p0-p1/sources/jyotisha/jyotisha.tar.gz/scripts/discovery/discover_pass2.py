#!/usr/bin/env python3
"""Discovery pass 2: new title families + direct identifier inspection.
No rights calls here (gate at acquisition)."""
import json, time, urllib.request, urllib.parse

UA = {"User-Agent": "jyotisha-corpus/1.0"}
ARCHIVE_SEARCH = "https://archive.org/advancedsearch.php"
ARCHIVE_META = "https://archive.org/metadata/"

TITLES = [
    "Tajika Neelakanthi", "Tajika", "Varshaphala", "Prashna Marga", "Prashna Tantra",
    "Graha Laghavam", "Uttara Kalamrita", "Jataka Tattva", "Satya Jatakam", "Sanketa Nidhi",
    "Garga Hora", "Yavana Jataka", "Panchasiddhantika", "Shatpanchasika", "Hora Sara",
    "Ashtakavarga", "Shadbala", "Brihat Parashara Hora Shastra Sanskrit", "Phaladeepika Sanskrit",
    "Muhurta Chintamani Sanskrit", "Deva Keralam", "Saptarishi Nadi", "Bhrigu Sutram",
    "Tithi Chintamani", "Jataka Chandrika", "Chamatkar Chintamani", "Varshaphala Dhundhiraja",
    "Nadi astrology", "Prashna", "Bhrigu",
]
DIRECT = ["brihatjatakaofvarahamihiravivruttiofbhattolpalasitaramjha_202003_434_V",
          "muhurta-chintamani-hindi", "jyotisha"]

def get(url, params=None, doseq=False, timeout=30):
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=doseq)
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

out = {}
print("=== PASS 2 TITLE SEARCH ===", flush=True)
for t in TITLES:
    try:
        d = get(ARCHIVE_SEARCH, {"q": f'title:({t}) AND mediatype:texts',
                                 "fl[]": ["identifier", "title", "year", "creator", "downloads"],
                                 "rows": 4, "sort": "downloads desc", "output": "json"}, doseq=True)
        docs = d.get("response", {}).get("docs", [])
    except Exception as e:
        docs = [{"_error": str(e)[:50]}]
    out[t] = docs
    for doc in docs:
        if "_error" in doc: print(f"[{t[:20]:20}] ERR {doc['_error']}"); continue
        def flat(v):
            if isinstance(v, list): return ", ".join(str(x) for x in v[:2])
            return str(v or "")
        print(f"[{t[:20]:20}] {doc['identifier'][:46]:46} {flat(doc.get('year'))[:10]:10} dl={doc.get('downloads',0):>7} | {flat(doc.get('creator'))[:24]}")
    time.sleep(0.3)

print("\n=== DIRECT IDENTIFIERS ===", flush=True)
for ident in DIRECT:
    try:
        d = get(ARCHIVE_META + ident)
        md = d.get("metadata", {})
        files = d.get("files", [])
        pdfs = [f["name"] for f in files if f["name"].lower().endswith(".pdf")]
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        desc = (md.get("description") or "")[:150].replace("\n", " ")
        out[ident] = {"identifier": ident, "title": md.get("title", "")[:80],
                      "creator": str(md.get("creator", ""))[:50], "desc": desc,
                      "pdfs": pdfs[:8], "djvu": djvu[:2], "files_total": len(files)}
        print(f"{ident[:50]:50} pdfs={len(pdfs)} djvu={'Y' if djvu else 'N'} total_files={len(files)}")
        print(f"   title: {out[ident]['title']}")
        print(f"   desc: {desc}")
        for p in pdfs[:8]:
            print(f"   pdf: {p}")
    except Exception as e:
        print(f"{ident}: ERR {str(e)[:60]}")
    time.sleep(0.3)

json.dump(out, open("logs/discovery-pass2.json", "w", encoding="utf-8"), indent=1, default=str)
print("\nsaved logs/discovery-pass2.json")
