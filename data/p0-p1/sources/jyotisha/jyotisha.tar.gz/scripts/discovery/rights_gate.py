#!/usr/bin/env python3
"""Rights gate: check archive.org metadata for shortlisted items, classify
ACQUIRE (explicit PD / no-known-copyright) vs CATALOG_ONLY (in copyright or unclear)."""
import json, time, urllib.request, urllib.parse, sys

UA = {"User-Agent": "jyotisha-corpus/1.0"}
SHORTLIST = [
    "BPHSEnglish", "BrihatJataka2ndEd.ByVSubrahmanyaSastri", "brihatjataka00varaiala",
    "Brihatsamhita", "bihatsahitvarah00iyergoog", "LaghuParashariSRJha",
    "in.ernet.dli.2015.486584", "muhurta-chintamani-hindi", "surya-siddhanta_202102",
    "SuryaSiddhantaTranslation", "SuryaSiddhanta_201311", "jyotisha",
    "HoraSaraRSanthanamEng", "Phaladeepika2ndEd.1950ByVSubrahmanyaSastri",
    "hindubookofastro00bhakrich", "kupdf.net_uttkalamitra-kalidas-ps-sastri",
    "JatakaParijataVolIOfIIByVSubrahmanyaSastri", "BhavarthaRatnakaraByBVRaman",
    "LaghuParashariOPVerma", "muhurtamartandadr.satyendramishra",
    "muhurta-chintamani-kedar-datt-joshi", "ThreeHundredImportantCombinationsInVedicAstrology",
    "XpDV_jataka-parijata-with-explanation-of-pt.-kapil", "saravali00kalyuoft",
    "dli.ministry.25756", "JatakaParijata1932", "BrihatSamhitaDr.SurkantJha",
    "Book11.HoraRatnam10NoOCR", "saravaliofkalyanavarmasanthanamr.astrology_202003_",
    "in.ernet.dli.2015.406251", "bhrigu-nandi-nadi", "in.ernet.dli.2015.274358",
    "laghu-parashari-o.-p.-verma", "sarvartha-chintamani-mahidhar-sharma",
    "in.ernet.dli.2015.406048", "in.ernet.dli.2015.92117", "brihat-parashara-hora-sastra",
    "in.ernet.dli.2015.553968", "AManualOfHinduAstrologyBVRaman1935Edition",
    "jmbQ_hindu-predictive-astrology-b.-v.-raman", "bhriguprashnanadiraor.g.astrology_202003_364_S",
]

def get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def classify(rights, lic, coll):
    r = (rights or "").lower()
    if "no known copyright" in r or "public domain" in r or "pd" in r.split():
        return "ACQUIRE"
    if "in copyright" in r or "copyrighted" in r or "all rights reserved" in r:
        return "CATALOG_ONLY"
    # DLI scans (in.ernet.dli, dli.ministry) are Indian govt digitizations of old books
    if any("dli" in c for c in coll) and "copyright" not in r:
        return "ACQUIRE_DLI"
    return "REVIEW"

out = {}
for ident in SHORTLIST:
    try:
        d = get(f"https://archive.org/metadata/{ident}")
        md = d.get("metadata", {})
        rights = md.get("rights", "") or ""
        lic = md.get("licenseurl", "") or ""
        coll = md.get("collection", [])
        if isinstance(coll, str): coll = [coll]
        files = d.get("files", [])
        pdfs = [f["name"] for f in files if f["name"].lower().endswith(".pdf")]
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        out[ident] = {
            "title": (md.get("title") or "")[:80],
            "creator": (md.get("creator") or md.get("creator") and "") or "",
            "year": md.get("year", "") or "",
            "rights": rights[:120],
            "license": lic,
            "collections": coll[:5],
            "pdfs": pdfs[:6],
            "djvu_txt": djvu[:2],
            "files_total": len(files),
        }
        cls = classify(rights, lic, coll)
        print(f"[{cls:11}] {ident[:46]:46} | {str(out[ident]['year'])[:8]:8} | pdfs={len(pdfs)} djvu={'Y' if djvu else 'N'} | {out[ident]['title'][:42]}")
    except Exception as e:
        out[ident] = {"error": str(e)[:100]}
        print(f"[ERROR     ] {ident}: {str(e)[:80]}")
    time.sleep(0.25)

with open("logs/rights-gate.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=1, default=str)
print("\nsaved logs/rights-gate.json")
