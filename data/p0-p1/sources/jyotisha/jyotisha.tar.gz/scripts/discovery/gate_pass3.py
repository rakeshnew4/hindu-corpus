#!/usr/bin/env python3
"""Gate pass 3: archive items surfaced via sanskritdocuments.org links."""
import json, time, urllib.request

UA = {"User-Agent": "jyotisha-corpus/1.0"}
ITEMS = [
    "brihatsamhitavarahamihirabruhatkernh.asiaticsociety1865_754_d",
    "brihatsamhitaenglishtranslationchidambaramiyerwithappendix1885_432_w",
    "varahi-brihat-samhita-1933-lakshmi-venkateshwar-press",
    "brihatsamhitawithhinditikabaldevprasadmishra1948khemraj_807_X",
    "wg873", "in.ernet.dli.2015.408097", "ShatpanchashikaVSSastri",
    "bhrigusutramgskapoor_202002",
    "bmmv_brihat-parashar-hora-shastra-of-parashar-muni-with-sudha-commentary-by-pt.-dev-c",
    "JvEo_brihat-samhita-of-bhattotpal-with-vimala-hindi-commentary-by-pt.-achyuta-nand-jh",
    "dhSS_brihat-samhita-of-bhattotpal-with-vimala-hindi-commentary-by-pt.-achyuta-nand-jh",
    "lPan_brihat-samhita-of-sri-varaha-mihira-part-2-with-bhattotpala-commentary-edited-by",
    "varahi-brihat-samhita-of-varahmihir-pandit-baldev-prasad-muradabad",
    "Laghujatkam", "ParasharaHoraSastra",
]

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

out = {}
for ident in ITEMS:
    try:
        d = get(f"https://archive.org/metadata/{ident}")
        md = d.get("metadata", {})
        files = d.get("files", [])
        def flat(v):
            if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
            return str(v or "")
        pdfs = [(f["name"], int(f.get("size") or 0) // (1 << 20)) for f in files if f["name"].lower().endswith(".pdf")]
        pdfs.sort(key=lambda x: -x[1])
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        rec = {"title": flat(md.get("title"))[:90], "creator": flat(md.get("creator"))[:60],
               "date": flat(md.get("date")), "year": flat(md.get("year")),
               "rights": (md.get("rights") or "")[:100],
               "collections": [str(c) for c in (md.get("collection") or [])][:4],
               "pdfs": pdfs[:3], "djvu": djvu[:1]}
        out[ident] = rec
        print(f"{ident[:52]:52} | {rec['date'][:12]:12} | {rec['creator'][:24]:24} | pdfs={pdfs[:2]} djvu={'Y' if djvu else 'N'}")
        print(f"    T: {rec['title'][:80]}")
        if rec["rights"]: print(f"    R: {rec['rights']}")
    except Exception as e:
        out[ident] = {"error": str(e)[:80]}
        print(f"{ident[:52]:52} | ERR {str(e)[:60]}")
    time.sleep(0.25)

json.dump(out, open("logs/gate-pass3.json", "w", encoding="utf-8"), indent=1, default=str)
