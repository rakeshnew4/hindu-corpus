#!/usr/bin/env python3
"""Pass 2 rights gate + inspection. Prints compact; saves logs/gate-pass2.json"""
import json, time, urllib.request

UA = {"User-Agent": "jyotisha-corpus/1.0"}

SHORTLIST = [
    "brihatjatakaofvarahamihiravivruttiofbhattolpalasitaramjha_202003_434_V",
    "zwux_graha-laghavam-by-ganesha-daivagya-sanskr",
    "panchasiddhantik025329mbp", "in.ernet.dli.2015.110157", "wg1078", "dli.csl.6388",
    "dli.ministry.22678", "in.ernet.dli.2015.473674", "dli.ernet.496259",
    "jatakatattvaofmahedevasubrahmanyasastriv.astro",
    "gargahorashastrapathakk.k._202003_150_g", "jmoh_7-stri-jataka-vriddha-yavana-devanagari-k",
    "Ashtakavarga1957Ed.ByCSPatelAiyar", "xpnh_brihat-parashara-hora-shastra-purva-uttar",
    "reoo_brihat-parashara-hora-shastra-subodhini-c",
    "Vkfo_muhurta-chintamani-of-rama-daivajnya-with", "UCCy_muhurta-chintamani-of-rama-daivajnya-with",
    "cfdT_muhurta-chintamani-with-piyush-dhara-comm", "in.ernet.dli.2015.489052",
    "deva-keralam-1-chandrakala-nadi", "mgos_20190802", "YQsI_bhrigu-sutram-with-hindi-tika-by-pt.-sidd",
    "tithichintamaniofganesadavignadattatreyabalava",
    "jatakachandrikachundrikavenkateshapanditamoonl", "chamatkar-chintamani-of-bhatta-narayana-pdf",
    "in.ernet.dli.2015.134427", "in.ernet.dli.2015.553830", "bhrigu-samhita",
    "uttara-kalamrita-kalidas", "Djxb_ramagya-prashna-of-goswami-tulsi-das-gita",
    "muhurta-chintamani-hindi", "jyotisha", "chamatkarchintamanibrajbiharilalsharma",
]

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

out = {}
for ident in SHORTLIST:
    try:
        d = get(f"https://archive.org/metadata/{ident}")
        md = d.get("metadata", {})
        files = d.get("files", [])
        def flat(v):
            if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
            return str(v or "")
        pdfs = sorted([(f["name"], f.get("size", 0)) for f in files if f["name"].lower().endswith(".pdf")],
                      key=lambda x: -int(x[1] or 0))
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        rec = {
            "title": flat(md.get("title"))[:90], "creator": flat(md.get("creator"))[:60],
            "year": flat(md.get("year")), "date": flat(md.get("date")),
            "rights": (md.get("rights") or "")[:100],
            "collections": [str(c) for c in (md.get("collection") or [])][:4],
            "desc": (md.get("description") or "")[:160].replace("\n", " "),
            "pdfs": [(n, int(s or 0) // (1 << 20)) for n, s in pdfs[:3]],
            "djvu": djvu[:1],
        }
        out[ident] = rec
        print(f"===== {ident[:52]}")
        print(f"  T: {rec['title']}")
        print(f"  C: {rec['creator']} | Y: {rec['year']} | D: {rec['date']}")
        print(f"  R: {rec['rights']} | COLL: {rec['collections']}")
        print(f"  DESC: {rec['desc'][:140]}")
        print(f"  PDFS: {rec['pdfs']} DJVU: {'Y' if rec['djvu'] else 'N'}")
    except Exception as e:
        out[ident] = {"error": str(e)[:80]}
        print(f"===== {ident}\n  ERR: {str(e)[:80]}")
    time.sleep(0.25)

json.dump(out, open("logs/gate-pass2.json", "w", encoding="utf-8"), indent=1, default=str)
print("\nsaved logs/gate-pass2.json")
