#!/usr/bin/env python3
"""Discovery pass 1: archive.org classical texts + GitHub software repos.
Outputs a compact candidate list; full registry records are written after verification."""
import json, time, urllib.request, urllib.parse, sys

ARCHIVE_SEARCH = "https://archive.org/advancedsearch.php"
ARCHIVE_META = "https://archive.org/metadata/"
GH_SEARCH = "https://api.github.com/search/repositories"

UA = {"User-Agent": "jyotisha-corpus-discovery/1.0 (research archive)"}

TARGET_TITLES = [
    "Brihat Jataka", "Brihat Samhita", "Brihat Parashara Hora Shastra",
    "Parashara Hora Shastra", "Saravali", "Phaladeepika", "Jataka Parijata",
    "Uttara Kalamrita", "Hora Sara", "Laghu Parashari", "Jataka Tattva",
    "Bhavartha Ratnakara", "Muhurta Chintamani", "Prashna Marga",
    "Tajika Neelakanthi", "Jaimini Sutras", "Satya Jatakam", "Surya Siddhanta",
    "Graha Laghavam", "Yavana Jataka", "Hora Ratnam", "Sanketa Nidhi",
    "Garga Hora", "Karma Prakasha", "Bhrigu Nandi Nadi", "Muhurta Martanda",
    "Panchasiddhantika", "Deva Keralam", "Jataka Chandrika", "Sarvartha Chintamani",
    "Vedic astrology", "Hindu astrology", "Nadi astrology",
]

def get(url, params=None, timeout=30, doseq=False):
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=doseq)
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def archive_search(title):
    params = {
        "q": f'title:({title}) AND mediatype:texts',
        "fl[]": ["identifier", "title", "year", "creator", "downloads"],
        "rows": 4, "sort": "downloads desc", "output": "json",
    }
    try:
        d = get(ARCHIVE_SEARCH, params, doseq=True)
        return d.get("response", {}).get("docs", [])
    except Exception as e:
        return [{"_error": str(e)}]

def archive_rights(identifier):
    """Called only for shortlisted items at acquisition time."""
    try:
        d = get(ARCHIVE_META + identifier)
        md = d.get("metadata", {})
        rights = md.get("rights", "") or ""
        lic = md.get("licenseurl", "") or ""
        coll = md.get("collection", [])
        if isinstance(coll, str): coll = [coll]
        return rights[:90], lic[:60], coll
    except Exception as e:
        return "", "", []

def gh_search(q, per_page=8):
    try:
        d = get(GH_SEARCH, {"q": q, "sort": "stars", "order": "desc", "per_page": per_page})
        out = []
        for r in d.get("items", []):
            lic = (r.get("license") or {}).get("spdx_id") or "none"
            out.append({"full_name": r["full_name"], "stars": r["stargazers_count"],
                        "license": lic, "desc": (r.get("description") or "")[:80],
                        "updated": (r.get("updated_at") or "")[:10], "url": r["html_url"]})
        return out
    except Exception as e:
        return [{"_error": str(e)}]

def main():
    results = {}
    print("=== ARCHIVE.ORG CLASSICAL TEXT DISCOVERY ===", flush=True)
    for t in TARGET_TITLES:
        docs = archive_search(t)
        candidates = []
        for d in docs:
            if "_error" in d:
                candidates.append({"identifier": f"ERR:{d['_error'][:40]}"}); continue
            def flat(v):
                if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
                return str(v or "")
            candidates.append({
                "identifier": d["identifier"], "title": flat(d.get("title"))[:70],
                "year": flat(d.get("year")), "creator": flat(d.get("creator"))[:40],
                "downloads": int(d.get("downloads") or 0), "rights": "", "license": "",
                "collections": [],
            })
        results[t] = candidates
        for c in candidates:
            if c.get("identifier", "").startswith("ERR"): continue
            print(f"  [{t[:24]:24}] {c['identifier']:44} | {c['year']:10} | dl={c['downloads']:>7} | {c['creator'][:24]}")
        time.sleep(0.25)

    print("\n=== GITHUB SOFTWARE DISCOVERY ===", flush=True)
    gh_all = {}
    for q in ["vedic astrology", "jyotisha", "kundli", "panchanga", "horoscope sanskrit"]:
        rows = gh_search(q)
        gh_all[q] = rows
        for r in rows:
            if "_error" in r: print(f"  [{q}] ERR {r['_error']}"); continue
            print(f"  [{q:16}] {r['full_name'][:44]:44} | ⭐{r['stars']:>5} | {r['license'][:12]:12} | {r['updated']} | {r['desc']}")
        time.sleep(1)

    with open("logs/discovery-pass1.json", "w", encoding="utf-8") as f:
        json.dump({"archive": results, "github": gh_all}, f, indent=1, default=str)
    print("\nSaved logs/discovery-pass1.json")

if __name__ == "__main__":
    main()
