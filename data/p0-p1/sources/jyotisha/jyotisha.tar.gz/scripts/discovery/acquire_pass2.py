#!/usr/bin/env python3
"""Acquisition pass 2. Explicit decisions + auto-gate for full-id retries + Sanskrit bundle per-file."""
import json, os, time, urllib.request, urllib.parse, hashlib

UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"

# (archive_id, source_id, note) — explicit decisions
ACQUIRE = [
    ("panchasiddhantik025329mbp", "TXT-panchasiddhantika-1882", "Panchasiddhantika, 1882"),
    ("in.ernet.dli.2015.110157", "TXT-panchasiddhantika-dvivedi1889", "Panchasiddhantika, Dvivedi ed. 1889"),
    ("wg1078", "TXT-panchasiddhantika-thibaut1889", "Panchasiddhantika, Thibaut trans. 1889"),
]
ACQUIRE_NOTE = [
    ("brihatjatakaofvarahamihiravivruttiofbhattolpalasitaramjha_202003_434_V", "TXT-brihat-jataka-bhattotpala-vivrutti", "Bhattotpala's Vivrutti commentary, Sitaram Jha ed., early 20th c."),
    ("dli.ministry.22678", "TXT-shatpanchasika-1941", "Shatpanchasika of Prithuyasas, trans. V.S. Sastri, 1941"),
    ("dli.ernet.496259", "TXT-jataka-tattva-sastri", "Jataka Tattva of Mahadeva, trans. Sastri (PDF 213MB -> text layer only)"),
    ("gargahorashastrapathakk.k._202003_150_g", "TXT-garga-hora-pathak", "Garga Hora Shastra, K.K. Pathak ed. (DLI)"),
    ("Ashtakavarga1957Ed.ByCSPatelAiyar", "TXT-ashtakavarga-patel-aiyar1957", "Ashtakavarga, C.S. Patel & Aiyar, 1957"),
    ("in.ernet.dli.2015.553830", "TXT-bhrigu-sanhita-paddhati-1949", "Bhrigu Sanhita Paddhati, 1949 (author n/a)"),
    ("uttara-kalamrita-kalidas", "TXT-uttara-kalamrita-sastri1937", "Uttara Kalamrita, trans. P.S. Sastri 1937 (2021 upload)"),
    ("in.ernet.dli.2015.134427", "TXT-nadi-jyothisha-1931", "Nadi Jyothisha (stellar system), part II, 1931"),
    ("in.ernet.dli.2015.489052", "TXT-deva-keralam-1992", "Deva Keralam, text attributed to Achyuta Pisharati (16th c), 1992 print"),
]
# auto-gate full-id retries (from discovery-pass2.json): (log-key, source_id)
AUTO = [
    ("xpnh_brihat-parashara-hora-shastra-purva-uttar", "TXT-bphs-sanskrit-egangotri"),
    ("reoo_brihat-parashara-hora-shastra-subodhini-c", "TXT-bphs-subodhini-khemaraj"),
    ("Vkfo_muhurta-chintamani-of-rama-daivajnya-with", "TXT-muhurta-chintamani-sanskrit-piyushadhara"),
    ("UCCy_muhurta-chintamani-of-rama-daivajnya-with", "TXT-muhurta-chintamani-sanskrit2"),
    ("cfdT_muhurta-chintamani-with-piyush-dhara-comm", "TXT-muhurta-chintamani-sanskrit-venkatesh"),
    ("YQsI_bhrigu-sutram-with-hindi-tika-by-pt.-sidd", "TXT-bhrigu-sutram-hindi-tika"),
    ("tithichintamaniofganesadavignadattatreyabalava", "TXT-tithi-chintamani"),
    ("jatakachandrikachundrikavenkateshapanditamoonl", "TXT-jataka-chandrika"),
    ("Djxb_ramagya-prashna-of-goswami-tulsi-das-gita", "TXT-ramagya-prashna"),
    ("zwux_graha-laghavam-by-ganesha-daivagya-sanskr", "TXT-graha-laghavam-sanskrit"),
    ("jmoh_7-stri-jataka-vriddha-yavana-devanagari-k", "TXT-yavana-jataka-devanagari"),
]
BUNDLE = "jyotisha"
MAX_MB = 130

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def fsize(p):
    try: return int(p.get("size") or 0)
    except (TypeError, ValueError): return 0

def download(url, dest, max_mb=MAX_MB, attempts=4):
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as f:
                total = 0
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    total += len(chunk)
                    if total > max_mb * (1 << 20):
                        os.remove(tmp); return None, "too large"
                    f.write(chunk)
            os.replace(tmp, dest)
            return total, "ok"
        except Exception as e:
            if i == attempts - 1: return None, str(e)[:80]
            time.sleep(3 * (i + 1))
    return None, "unknown"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def acquire_one(ident, sid, note, decision, max_mb=MAX_MB, want_djvu=True, want_pdf=True):
    outdir = os.path.join("raw", sid)
    os.makedirs(outdir, exist_ok=True)
    try:
        d = get(f"https://archive.org/metadata/{ident}")
    except Exception as e:
        print(f"[ERR] {sid}: {str(e)[:60]}"); return None
    md = d.get("metadata", {})
    files = d.get("files", [])
    def flat(v):
        if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
        return str(v or "")
    rec = {"archive_id": ident, "source_id": sid, "decision": decision, "note": note,
           "title": flat(md.get("title"))[:100], "creator": flat(md.get("creator"))[:60],
           "year": flat(md.get("year")), "date": flat(md.get("date")),
           "rights": (md.get("rights") or "")[:100],
           "access_status": "PUBLIC_DOMAIN" if decision == "ACQUIRE" else "PD_IN_INDIA_LIKELY"}
    got = []
    if want_djvu:
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        if djvu:
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(djvu[0]),
                             os.path.join(outdir, djvu[0]))
            if st == "ok": rec["text_file"] = djvu[0]; rec["text_bytes"] = n; got.append(djvu[0])
    if want_pdf:
        pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
        pdf = None
        for p in sorted(pdfs, key=lambda p: -fsize(p)):
            if fsize(p) <= max_mb * (1 << 20): pdf = p; break
        if pdf:
            fn = pdf["name"]
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                             os.path.join(outdir, fn))
            if st == "ok":
                rec["pdf_file"] = fn; rec["pdf_bytes"] = n
                rec["file_hash"] = "sha256:" + sha256(os.path.join(outdir, fn))
                got.append(fn)
            else:
                rec["pdf_error"] = st
        elif pdfs:
            rec["pdf_error"] = f"largest pdf {max(fsize(p) for p in pdfs)//(1<<20)}MB > cap {max_mb}MB"
    rec["acquired_files"] = got
    rec["acquisition_date"] = "2026-08-31"
    rec["acquisition_method"] = "archive.org direct download"
    print(f"[{decision:12}] {sid:42} files={len(got)}")
    return rec

def main():
    results = []
    # full ids from discovery-pass2.json for auto-gate retries
    disc = json.load(open("logs/discovery-pass2.json", encoding="utf-8"))
    full_ids = {}
    for key, sid in AUTO:
        docs = disc.get(key, [])
        if isinstance(docs, list) and docs:
            ident = docs[0].get("identifier") if isinstance(docs[0], dict) else None
            if ident and not str(ident).startswith("ERR"):
                full_ids[ident] = (sid, key)
    for ident, sid in [(a[0], a[1]) for a in ACQUIRE + ACQUIRE_NOTE]:
        full_ids[ident] = (sid, "")
    # explicit decisions
    for ident, sid, note in ACQUIRE:
        r = acquire_one(ident, sid, note, "ACQUIRE")
        if r: results.append(r)
    for ident, sid, note in ACQUIRE_NOTE:
        r = acquire_one(ident, sid, note, "ACQUIRE_NOTE")
        if r: results.append(r)
    # auto-gate items
    for ident, (sid, key) in full_ids.items():
        if sid in [s for _, s in ACQUIRE] + [s for _, s in ACQUIRE_NOTE]:
            continue
        try:
            d = get(f"https://archive.org/metadata/{ident}")
            md = d.get("metadata", {})
            coll = [str(c) for c in (md.get("collection") or [])]
            year = md.get("year") or md.get("date") or ""
            if isinstance(year, list): year = year[0] if year else ""
            year_s = str(year)
            creator = str(md.get("creator") or "")
            modern = any(m in creator.lower() for m in ["raman", "santhanam", "rath", "charak", "sharma", "srivastava", "verma"])
            dli = any("dli" in c or "jai" in c or "egangotri" in c for c in coll)
            if modern and not dli:
                print(f"[CATALOG_ONLY] {sid:42} modern author: {creator[:40]}")
                continue
            if dli or (year_s and int(year_s[:4]) <= 1960 if year_s[:4].isdigit() else False):
                r = acquire_one(ident, sid, f"auto-gate: DLI={dli} year={year_s} coll={coll[:3]}", "ACQUIRE_NOTE")
                if r: results.append(r)
            else:
                print(f"[CATALOG_ONLY] {sid:42} year={year_s} coll={coll[:3]}")
        except Exception as e:
            print(f"[ERR] {sid}: {str(e)[:60]}")
        time.sleep(0.3)
    # bundle: all PDFs
    try:
        d = get(f"https://archive.org/metadata/{BUNDLE}")
        files = d.get("files", [])
        pdfs = sorted([f for f in files if f["name"].lower().endswith(".pdf")], key=lambda p: -fsize(p))
        outdir = os.path.join("raw", "TXT-sanskrit-bundle")
        os.makedirs(outdir, exist_ok=True)
        got = []
        for p in pdfs:
            if fsize(p) > MAX_MB * (1 << 20):
                print(f"[SKIP] bundle {p['name'][:50]} {fsize(p)//(1<<20)}MB > cap"); continue
            n, st = download(BASE + urllib.parse.quote(BUNDLE) + "/" + urllib.parse.quote(p["name"]),
                             os.path.join(outdir, p["name"]))
            if st == "ok": got.append(p["name"])
            time.sleep(0.5)
        results.append({"archive_id": BUNDLE, "source_id": "TXT-sanskrit-bundle", "decision": "ACQUIRE",
                        "note": "Sanskrit DLI bundle: 12 PDFs incl. Jataka Bharanam, Daivagya Kamadhenu, Hora Shastra (Varahamihira), Brihat Samhita (Iyer)",
                        "acquired_files": got, "acquisition_date": "2026-08-31",
                        "acquisition_method": "archive.org direct download",
                        "access_status": "PUBLIC_DOMAIN", "text_quality": "RAW_ONLY_OCR_POOR"})
        print(f"[ACQUIRE] TXT-sanskrit-bundle files={len(got)}")
    except Exception as e:
        print(f"[ERR] bundle: {str(e)[:80]}")

    # merge into registry
    reg_path = "sources/sources-registry.json"
    reg = json.load(open(reg_path, encoding="utf-8"))
    have = {r["source_id"] for r in reg}
    new = [r for r in results if r and r["source_id"] not in have]
    reg.extend(new)
    json.dump(reg, open(reg_path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"\nregistry now: {len(reg)} records (+{len(new)} new)")

if __name__ == "__main__":
    main()
