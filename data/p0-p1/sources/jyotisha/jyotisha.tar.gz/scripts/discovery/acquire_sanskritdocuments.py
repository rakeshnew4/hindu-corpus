#!/usr/bin/env python3
"""Acquire sanskritdocuments.org Jyotisha .itx texts (machine-readable Sanskrit).
Volunteer site: texts 'prepared by volunteers... for personal study and research'.
Records provenance; itx IS the clean text layer (no OCR needed)."""
import json, os, re, time, urllib.request, hashlib

UA = {"User-Agent": "jyotisha-corpus/1.0 (research archive; personal study)"}
BASE = "https://sanskritdocuments.org/doc_z_misc_sociology_astrology/"

TEXTS = [
    ("bRRihatsaMhitA", "TXT-SD-brihat-samhita-sanskrit", "Brihat Samhita of Varahamihira, Sanskrit (ITRANS)"),
    ("bhrigusUtram", "TXT-SD-bhrigu-sutram", "Bhrigu Sutram, Sanskrit (ITRANS)"),
    ("brihajjAtakam", "TXT-SD-brihat-jataka-sanskrit", "Brihat Jataka of Varahamihira, Sanskrit (ITRANS)"),
    ("chamatkarachintamani", "TXT-SD-chamatkar-chintamani", "Chamatkarachintamani of Bhatta Narayana, Sanskrit (ITRANS)"),
    ("daivaGYavallabha", "TXT-SD-daivajnavallabha", "Daivajnavallabha of Varahamihira, Sanskrit (ITRANS)"),
    ("jAtakapArijAtaH", "TXT-SD-jataka-parijata-sanskrit", "Jataka Parijata of Vaidyanatha Dikshita, Sanskrit (ITRANS)"),
    ("laghujAtaka", "TXT-SD-laghu-jataka", "Laghu Jataka, Sanskrit (ITRANS)"),
    ("phaladIpika", "TXT-SD-phaladeepika-sanskrit", "Phaladeepika of Mantreswara, Sanskrit (ITRANS)"),
    ("varbrhs", "TXT-SD-varbrhs", "Varahamihira Brihat Samhita (varbrhs), Sanskrit (ITRANS)"),
    ("vriddhayavanajataka1", "TXT-SD-vriddha-yavana-jataka", "Vriddha Yavana Jataka of Sphujidhvaja, Sanskrit (ITRANS)"),
    ("yaajuShajyotiSha", "TXT-SD-yajush-jyotisha", "Yajush Jyotisha (Vedanga), Sanskrit (ITRANS)"),
    ("ShaTpanchAshikA", "TXT-SD-shatpanchasika-sanskrit", "Shatpanchasika of Prithuyasas, Sanskrit (ITRANS)"),
    ("aarchajyotiSha", "TXT-SD-archa-jyotisha", "Archa Jyotisha, Sanskrit (ITRANS)"),
    ("horaashaastraEng34-45", "TXT-SD-bphs-eng34-45", "BPHS ch. 34-45 English meaning (Ahto Jarve), secondary"),
]
BPHS_PARTS = [("par%02d%d0" % (n, n-1) if False else f"par{n:02d}{n+9:02d}".replace("010", "0110") if n == 1 else f"par{n*10-9}{n*10:02d}") for n in range(1, 12)]

def get_text(slug):
    url = BASE + slug + ".itx"
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read().decode("utf-8", "replace")

def strip_header(itx):
    """Remove % comment header, keep text body."""
    lines = itx.split("\n")
    body = [l for l in lines if not l.strip().startswith("%")]
    return "\n".join(body).strip()

def main():
    results = []
    for slug, sid, note in TEXTS:
        try:
            raw = get_text(slug)
            outdir = os.path.join("raw", sid)
            os.makedirs(outdir, exist_ok=True)
            fn = slug + ".itx"
            with open(os.path.join(outdir, fn), "w", encoding="utf-8") as f:
                f.write(raw)
            body = strip_header(raw)
            os.makedirs(os.path.join("texts", sid), exist_ok=True)
            with open(os.path.join("texts", sid, "full.txt"), "w", encoding="utf-8") as f:
                f.write(body)
            h = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            results.append({"source_id": sid, "title": note, "archive_id": None,
                            "url": BASE + slug + ".itx", "access_status": "OPEN_SITE_PERSONAL_RESEARCH",
                            "decision": "ACQUIRE", "reason": "volunteer-prepared text, personal study/research use",
                            "acquired_files": [fn], "file_hash": "sha256:" + h,
                            "text_quality": "ITX_TRANSLITERATED", "text_chars": len(body),
                            "acquisition_date": "2026-08-31", "acquisition_method": "sanskritdocuments.org direct",
                            "note": note, "chapters": 0})
            print(f"[OK] {sid:38} chars={len(body):>7}")
        except Exception as e:
            print(f"[ERR] {sid}: {str(e)[:70]}")
        time.sleep(0.4)
    # BPHS chapter files -> merged single source
    parts = []
    for n in range(1, 12):
        if n == 1:
            slug = "par0110"
        else:
            slug = f"par{n*10-9}{n*10:02d}"
        try:
            raw = get_text(slug)
            parts.append((slug, raw))
            print(f"[OK] BPHS part {slug}")
        except Exception as e:
            print(f"[ERR] BPHS part {slug}: {str(e)[:60]}")
        time.sleep(0.4)
    if parts:
        sid = "TXT-SD-bphs-sanskrit"
        outdir = os.path.join("raw", sid)
        os.makedirs(outdir, exist_ok=True)
        merged = "\n\n".join(strip_header(r) for _, r in parts)
        for slug, raw in parts:
            with open(os.path.join(outdir, slug + ".itx"), "w", encoding="utf-8") as f:
                f.write(raw)
        os.makedirs(os.path.join("texts", sid), exist_ok=True)
        with open(os.path.join("texts", sid, "full.txt"), "w", encoding="utf-8") as f:
            f.write(merged)
        h = hashlib.sha256(merged.encode("utf-8")).hexdigest()
        results.append({"source_id": sid, "title": "Brihat Parashara Hora Shastra, Sanskrit (ITRANS, 11 parts)",
                        "archive_id": None, "url": BASE + "par0110.itx (.. par9197.itx)",
                        "access_status": "OPEN_SITE_PERSONAL_RESEARCH", "decision": "ACQUIRE",
                        "reason": "volunteer-prepared Sanskrit text, personal study/research use",
                        "acquired_files": [s + ".itx" for s, _ in parts],
                        "file_hash": "sha256:" + h, "text_quality": "ITX_TRANSLITERATED",
                        "text_chars": len(merged), "acquisition_date": "2026-08-31",
                        "acquisition_method": "sanskritdocuments.org direct", "note": "BPHS Sanskrit, transliterated",
                        "chapters": 0})
        print(f"[OK] {sid}: merged {len(parts)} parts, {len(merged)} chars")
    # merge registry
    reg = json.load(open("sources/sources-registry.json", encoding="utf-8"))
    have = {r["source_id"] for r in reg}
    new = [r for r in results if r["source_id"] not in have]
    reg.extend(new)
    json.dump(reg, open("sources/sources-registry.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"\nregistry: {len(reg)} records (+{len(new)})")

if __name__ == "__main__":
    main()
