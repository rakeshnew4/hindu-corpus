#!/usr/bin/env python3
"""Acquisition pass 1: download legally-accessible primary texts from archive.org.
Gate: explicit PD rights | pub year <=1928 | (1929-1960 Indian pub, no rights flag -> ACQUIRE_NOTE).
Modern authors -> CATALOG_ONLY. Every decision logged; sha256 recorded; registry written."""
import json, time, urllib.request, urllib.parse, hashlib, os, sys

UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"
MODERN_AUTHORS = ["raman", "santhanam", "sanjay rath", "charak", "mishra", "surkant", "verma, o", "rao, r", "sharma, mahidhar"]

TARGETS = [
    ("bihatsahitvarah00iyergoog", "TXT-brihat-samhita-iyer1884", "Brihat Samhita, trans. N. Chidambaram Iyer, 1884"),
    ("brihatjataka00varaiala", "TXT-brihat-jataka-iyer1905", "Brihat Jataka, trans. N. Chidambaram Iyer, 1905"),
    ("saravali00kalyuoft", "TXT-saravali-1907", "Saravali of Kalyana Varma, trans. V. Subrahmanya Sastri, 1907"),
    ("hindubookofastro00bhakrich", "TXT-hindu-book-astrology-1902", "The Hindu Book of Astrology, 1902"),
    ("SuryaSiddhantaTranslation", "TXT-surya-siddhanta-burgess1860", "Surya Siddhanta, trans. Rev. E. Burgess, 1860"),
    ("LaghuParashariSRJha", "TXT-laghu-parashari-jha1900", "Laghu Parashari, Sitaram Jha, 1900"),
    ("in.ernet.dli.2015.406251", "TXT-brihat-jataka-rao1919", "Brihat Jataka English Translation, B. Suryanarain Rao, 1919"),
    ("BrihatJataka2ndEd.ByVSubrahmanyaSastri", "TXT-brihat-jataka-sastri-2ed", "Brihat Jataka, V. Subrahmanya Sastri, 2nd ed. (verify year)"),
    ("in.ernet.dli.2015.486584", "TXT-jaimini-sutras-rao1949", "Jaimini Sutras, B. Suryanarain Rao, 1949"),
    ("Phaladeepika2ndEd.1950ByVSubrahmanyaSastri", "TXT-phaladeepika-sastri1950", "Phaladeepika, V. Subrahmanya Sastri, 2nd ed. 1950"),
    ("in.ernet.dli.2015.406048", "TXT-phaladeepika-1937a", "Phaladeepika, 1937 (DLI)"),
    ("in.ernet.dli.2015.92117", "TXT-phaladeepika-1937b", "Mantreswara's Phaladeepika, 1937 (DLI)"),
    ("JatakaParijata1932", "TXT-jataka-parijata-sastri1932", "Jataka Parijata, V. Subrahmanya Sastri, 1932"),
    ("JatakaParijataVolIOfIIByVSubrahmanyaSastri", "TXT-jataka-parijata-vol1", "Jataka Parijata Vol I of II, V. Subrahmanya Sastri (verify year)"),
    ("Brihatsamhita", "TXT-brihat-samhita-sastri1946", "Brihat Samhita (verify edition/translation)"),
    ("jyotisha", "TXT-brihat-jataka-compilation", "Brihat Jataka compilation (verify)"),
    ("brihat-parashara-hora-sastra", "TXT-bphs-archive", "Brihat Parashara Hora Shastra (verify edition/language)"),
    ("muhurta-chintamani-kedar-datt-joshi", "TXT-muhurta-chintamani-kdj", "Muhurta Chintamani, Kedar Datt Joshi (verify year)"),
    ("surya-siddhanta_202102", "TXT-surya-siddhanta-hindi", "Surya Siddhanta, Sarvahitkari press Hindi (verify)"),
    ("SuryaSiddhanta_201311", "TXT-surya-siddhanta-201311", "Surya Siddhanta (verify)"),
    ("Book11.HoraRatnam10NoOCR", "TXT-hora-ratnam", "Hora Ratnam of Balabhadra (verify year)"),
    ("bhrigu-nandi-nadi", "TXT-bhrigu-nandi-nadi", "Bhrigu Nandi Nadi (verify provenance)"),
]

def get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def classify(md, creator, title):
    rights = (md.get("rights") or "").lower()
    year = md.get("year") or md.get("date") or ""
    if isinstance(year, list): year = year[0] if year else ""
    year = str(year).strip()[:4]
    creator_l = (creator or "").lower()
    if "no known copyright" in rights or "public domain" in rights:
        return "ACQUIRE", f"explicit rights: {rights[:60]}"
    try:
        y = int(year)
    except ValueError:
        y = None
    if y and y <= 1928:
        return "ACQUIRE", f"published {y} (pre-1929 US PD)"
    if any(m in creator_l for m in MODERN_AUTHORS):
        return "CATALOG_ONLY", f"modern author: {creator}"
    if y and 1929 <= y <= 1960:
        return "ACQUIRE_NOTE", f"published {y}, Indian publication, no rights flag; PD-in-India likely (verify author death)"
    return "REVIEW", f"year={year!r} creator={creator!r} rights={rights[:40]!r}"

def download(url, dest, max_mb=130):
    req = urllib.request.Request(url, headers=UA)
    tmp = dest + ".part"
    with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
        total = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk: break
            total += len(chunk)
            if total > max_mb * 1 << 20:
                os.remove(tmp)
                return None, "too large"
            f.write(chunk)
    os.replace(tmp, dest)
    return total, "ok"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    registry = []
    log = []
    for ident, sid, note in TARGETS:
        try:
            d = get(f"https://archive.org/metadata/{ident}")
        except Exception as e:
            log.append({"id": ident, "decision": "ERROR", "reason": str(e)[:80]})
            print(f"[ERROR    ] {sid:34} {str(e)[:60]}"); continue
        md = d.get("metadata", {})
        creator = md.get("creator", "") or ""
        if isinstance(creator, list): creator = ", ".join(str(c) for c in creator)
        title = (md.get("title") or "")[:100]
        decision, reason = classify(md, creator, title)
        files = d.get("files", [])
        pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        rec = {"archive_id": ident, "source_id": sid, "title": title, "creator": creator,
               "decision": decision, "reason": reason, "note": note, "pdfs": [f["name"] for f in pdfs][:3],
               "djvu_txt": djvu[:1], "date": md.get("date", ""), "year": md.get("year", "")}
        if decision in ("ACQUIRE", "ACQUIRE_NOTE"):
            outdir = os.path.join("raw", sid)
            os.makedirs(outdir, exist_ok=True)
            got = []
            if djvu:
                fn = djvu[0]
                n, status = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                                     os.path.join(outdir, fn))
                if status == "ok":
                    rec["text_file"] = fn; rec["text_bytes"] = n; got.append(fn)
                else:
                    rec["text_file_error"] = status
            # main PDF: largest under 130MB
            def fsize(p):
                try: return int(p.get("size") or 0)
                except (TypeError, ValueError): return 0
            pdf = None
            for p in sorted(pdfs, key=lambda p: -fsize(p)):
                if fsize(p) <= 130 * (1 << 20):
                    pdf = p; break
            if pdf:
                fn = pdf["name"]
                n, status = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(fn),
                                     os.path.join(outdir, fn))
                if status == "ok":
                    rec["pdf_file"] = fn; rec["pdf_bytes"] = n
                    rec["file_hash"] = "sha256:" + sha256(os.path.join(outdir, fn))
                    got.append(fn)
                else:
                    rec["pdf_file_error"] = status
            rec["acquired_files"] = got
            rec["acquisition_date"] = "2026-08-31"
            rec["acquisition_method"] = "archive.org direct download"
            rec["access_status"] = "PUBLIC_DOMAIN" if decision == "ACQUIRE" else "PD_IN_INDIA_LIKELY"
            registry.append(rec)
            print(f"[{decision:12}] {sid:34} files={len(got)} {reason}")
        else:
            rec["access_status"] = "CATALOG_ONLY"
            registry.append(rec)
            print(f"[{decision:12}] {sid:34} {reason}")
        log.append(rec)
        time.sleep(0.2)

    with open("sources/sources-registry.json", "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=1)
    with open("logs/acquisition-pass1.json", "w", encoding="utf-8") as f:
        json.dump(log, f, indent=1)
    print(f"\nregistry: {len(registry)} records -> sources/sources-registry.json")

if __name__ == "__main__":
    main()
