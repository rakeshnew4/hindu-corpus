#!/usr/bin/env python3
"""Recover pass-2 items lost to the crash: rebuild from disk + metadata, run auto-gate, download bundle."""
import json, os, time, urllib.request, urllib.parse, hashlib

UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"
MAX_MB = 130

PASS2_SIDS = {
    "TXT-panchasiddhantika-1882": "panchasiddhantik025329mbp",
    "TXT-panchasiddhantika-dvivedi1889": "in.ernet.dli.2015.110157",
    "TXT-panchasiddhantika-thibaut1889": "wg1078",
    "TXT-brihat-jataka-bhattotpala-vivrutti": "brihatjatakaofvarahamihiravivruttiofbhattolpalasitaramjha_202003_434_V",
    "TXT-shatpanchasika-1941": "dli.ministry.22678",
    "TXT-jataka-tattva-sastri": "dli.ernet.496259",
    "TXT-garga-hora-pathak": "gargahorashastrapathakk.k._202003_150_g",
    "TXT-ashtakavarga-patel-aiyar1957": "Ashtakavarga1957Ed.ByCSPatelAiyar",
    "TXT-bhrigu-sanhita-paddhati-1949": "in.ernet.dli.2015.553830",
    "TXT-uttara-kalamrita-sastri1937": "uttara-kalamrita-kalidas",
    "TXT-nadi-jyothisha-1931": "in.ernet.dli.2015.134427",
    "TXT-deva-keralam-1992": "in.ernet.dli.2015.489052",
}
AUTO = [
    ("xpnh_brihat-parashara-hora-shastra-purva-uttar", "TXT-bphs-sanskrit-egangotri"),
    ("reoo_brihat-parashara-hora-shastra-subodhini-c", "TXT-bphs-subodhini-khemaraj"),
    ("Vkfo_muhurta-chintamani-of-rama-daivajnya-with", "TXT-muhurta-chintamani-sanskrit-piyushadhara"),
    ("UCCy_muhurta-chintamani-of-rama-daivajnya-with", "TXT-muhurta-chintamani-sanskrit2"),
    ("cfdT_muhurta-chintamani-with-piyush-dhara-comm", "TXT-muhurta-chintamani-sanskrit-venkatesh"),
    ("YQsI_bhrigu-sutram-with-hindi-tika-by-pt.-sidd", "TXT-bhrigu-sutram-hindi-tika"),
    ("tithichintamaniofganesadavignadattatreyabalava", "TXT-tithi-chintamani"),
    ("jatakachandrikachundrikavenkateshapanditamoonl", "TXT-jataka-chandrika"),
    ("Djxb_ramagya-prashna-of-goswami-tulsi-das-gita", "TXT-ramagya-prashna"),
    ("zwux_graha-laghavam-by-ganesha-daivagya-sanskr", "TXT-graha-laghavam-sanskrit"),
    ("jmoh_7-stri-jataka-vriddha-yavana-devanagari-k", "TXT-yavana-jataka-devanagari"),
]
NOTES = {
    "TXT-brihat-jataka-bhattotpala-vivrutti": "Bhattotpala's Vivrutti commentary, Sitaram Jha ed., early 20th c.",
    "TXT-jataka-tattva-sastri": "Jataka Tattva of Mahadeva, trans. Sastri (PDF 213MB -> text layer only)",
    "TXT-garga-hora-pathak": "Garga Hora Shastra, K.K. Pathak ed. (DLI)",
    "TXT-ashtakavarga-patel-aiyar1957": "Ashtakavarga, C.S. Patel & Aiyar, 1957",
    "TXT-bhrigu-sanhita-paddhati-1949": "Bhrigu Sanhita Paddhati, 1949 (author n/a)",
    "TXT-uttara-kalamrita-sastri1937": "Uttara Kalamrita, trans. P.S. Sastri 1937 (2021 upload)",
    "TXT-nadi-jyothisha-1931": "Nadi Jyothisha (stellar system), part II, 1931",
    "TXT-deva-keralam-1992": "Deva Keralam, text attributed to Achyuta Pisharati (16th c), 1992 print",
}

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def fsize(p):
    try: return int(p.get("size") or 0)
    except (TypeError, ValueError): return 0

def download(url, dest, max_mb=MAX_MB, attempts=4):
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as f:
                total = 0
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    total += len(chunk)
                    if total > max_mb * (1 << 20):
                        os.remove(tmp); return None, "too large"
                    f.write(chunk)
            os.replace(tmp, dest)
            return total, "ok"
        except Exception as e:
            if i == attempts - 1: return None, str(e)[:80]
            time.sleep(3 * (i + 1))
    return None, "unknown"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def main():
    reg = json.load(open("sources/sources-registry.json", encoding="utf-8"))
    have = {r["source_id"] for r in reg}
    added = 0
    # 1) recover from disk
    for sid, ident in PASS2_SIDS.items():
        if sid in have: continue
        od = os.path.join("raw", sid)
        if not os.path.isdir(od):
            print(f"[MISSING] {sid} no files on disk"); continue
        names = sorted(os.listdir(od))
        rec = {"archive_id": ident, "source_id": sid, "decision": "ACQUIRE_NOTE",
               "note": NOTES.get(sid, "recovered from disk after pass-2 crash"),
               "access_status": "PD_IN_INDIA_LIKELY",
               "reason": "pre-1960 Indian publication / DLI scan (recovered from disk)",
               "acquired_files": names, "acquisition_date": "2026-08-31",
               "acquisition_method": "archive.org direct download (recovered)"}
        for n in names:
            if n.endswith("_djvu.txt") and not rec.get("text_file"): rec["text_file"] = n
            elif n.lower().endswith(".pdf") and not rec.get("pdf_file"):
                rec["pdf_file"] = n
                rec["file_hash"] = "sha256:" + sha256(os.path.join(od, n))
        try:
            md = get(f"https://archive.org/metadata/{ident}")["metadata"]
            def flat(v):
                if isinstance(v, list): return ", ".join(str(x) for x in v[:3])
                return str(v or "")
            rec["title"] = flat(md.get("title"))[:100]
            rec["creator"] = flat(md.get("creator"))[:60]
        except Exception:
            pass
        reg.append(rec); have.add(sid); added += 1
        print(f"[RECOVER ] {sid:40} files={len(names)}")
    # 2) auto-gate items
    disc = json.load(open("logs/discovery-pass2.json", encoding="utf-8"))
    for key, sid in AUTO:
        if sid in have: continue
        docs = disc.get(key, [])
        ident = docs[0].get("identifier") if docs and isinstance(docs[0], dict) else None
        if not ident or str(ident).startswith("ERR"):
            print(f"[NOID    ] {sid:40} key={key[:40]}"); continue
        try:
            d = get(f"https://archive.org/metadata/{ident}")
            md = d.get("metadata", {})
            coll = [str(c) for c in (md.get("collection") or [])]
            year = md.get("year") or md.get("date") or ""
            if isinstance(year, list): year = year[0] if year else ""
            creator = str(md.get("creator") or "")
            modern = any(m in creator.lower() for m in ["raman", "santhanam", "rath", "charak", "srivastava", "verma", "sharma"])
            dli = any("dli" in c or "jai" in c or "egangotri" in c for c in coll)
            ynum = int(str(year)[:4]) if str(year)[:4].isdigit() else None
            if modern and not dli:
                print(f"[CATALOG ] {sid:40} modern author {creator[:30]}"); continue
            if dli or (ynum and ynum <= 1960):
                outdir = os.path.join("raw", sid)
                os.makedirs(outdir, exist_ok=True)
                files = d.get("files", [])
                rec = {"archive_id": ident, "source_id": sid, "decision": "ACQUIRE_NOTE",
                       "title": str(md.get("title") or "")[:100], "creator": creator[:60],
                       "rights": (md.get("rights") or "")[:100],
                       "access_status": "PD_IN_INDIA_LIKELY",
                       "reason": f"auto-gate: DLI={dli} year={year} coll={coll[:3]}",
                       "note": key[:70], "acquisition_date": "2026-08-31",
                       "acquisition_method": "archive.org direct download"}
                got = []
                djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
                if djvu:
                    n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(djvu[0]),
                                     os.path.join(outdir, djvu[0]))
                    if st == "ok": rec["text_file"] = djvu[0]; got.append(djvu[0])
                pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
                pdf = None
                for p in sorted(pdfs, key=lambda p: -fsize(p)):
                    if fsize(p) <= MAX_MB * (1 << 20): pdf = p; break
                if pdf:
                    n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(pdf["name"]),
                                     os.path.join(outdir, pdf["name"]))
                    if st == "ok":
                        rec["pdf_file"] = pdf["name"]
                        rec["file_hash"] = "sha256:" + sha256(os.path.join(outdir, pdf["name"]))
                        got.append(pdf["name"])
                    else: rec["pdf_error"] = st
                elif pdfs:
                    rec["pdf_error"] = f"largest {max(fsize(p) for p in pdfs)//(1<<20)}MB > cap"
                rec["acquired_files"] = got
                reg.append(rec); have.add(sid); added += 1
                print(f"[AUTO    ] {sid:40} files={len(got)} {rec['pdf_error'] or ''}")
            else:
                print(f"[CATALOG ] {sid:40} year={year} coll={coll[:3]}")
        except Exception as e:
            print(f"[ERR     ] {sid}: {str(e)[:60]}")
        time.sleep(0.3)
    # 3) bundle
    if "TXT-sanskrit-bundle" not in have:
        try:
            d = get(f"https://archive.org/metadata/jyotisha")
            files = d.get("files", [])
            pdfs = sorted([f for f in files if f["name"].lower().endswith(".pdf")], key=lambda p: -fsize(p))
            outdir = os.path.join("raw", "TXT-sanskrit-bundle")
            os.makedirs(outdir, exist_ok=True)
            got = []
            for p in pdfs:
                if fsize(p) > MAX_MB * (1 << 20):
                    print(f"[SKIP] bundle {p['name'][:60]} {fsize(p)//(1<<20)}MB"); continue
                n, st = download(BASE + "jyotisha/" + urllib.parse.quote(p["name"]), os.path.join(outdir, p["name"]))
                if st == "ok": got.append(p["name"])
                time.sleep(0.4)
            reg.append({"archive_id": "jyotisha", "source_id": "TXT-sanskrit-bundle", "decision": "ACQUIRE",
                        "note": "Sanskrit DLI bundle: 12 PDFs incl. Jataka Bharanam, Daivagya Kamadhenu, Hora Shastra (Varahamihira)",
                        "access_status": "PUBLIC_DOMAIN", "acquired_files": got,
                        "acquisition_date": "2026-08-31", "acquisition_method": "archive.org direct download",
                        "text_quality": "RAW_ONLY_OCR_POOR"})
            print(f"[BUNDLE  ] files={len(got)}")
        except Exception as e:
            print(f"[ERR] bundle: {str(e)[:80]}")
    json.dump(reg, open("sources/sources-registry.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"\nregistry: {len(reg)} records (+{added})")

if __name__ == "__main__":
    main()
