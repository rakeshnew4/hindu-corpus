#!/usr/bin/env python3
"""Fetch the full corpus from public sources using sources/sources-registry.json.

Downloads the non-redistributed archive.org sources (ACQUIRE / ACQUIRE_NOTE items) into ./raw/,
respecting the registry's legal gate: CATALOG_ONLY (copyright) and DEFER items are skipped.
Re-run to resume/complete. Requires network access to archive.org."""
import json, os, sys, time, urllib.request, urllib.parse, hashlib

MAX_MB = 130
UA = {"User-Agent": "jyotisha-corpus/1.0"}
BASE = "https://archive.org/download/"

def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def fsize(p):
    try: return int(p.get("size") or 0)
    except (TypeError, ValueError): return 0

def download(url, dest, max_mb=MAX_MB, attempts=4):
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as f:
                total = 0
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk: break
                    total += len(chunk)
                    if total > max_mb * (1 << 20):
                        os.remove(tmp); return None, "too large"
                    f.write(chunk)
            os.replace(tmp, dest)
            return total, "ok"
        except Exception as e:
            if i == attempts - 1: return None, str(e)[:80]
            time.sleep(3 * (i + 1))
    return None, "unknown"

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    reg_path = os.path.join(here, "..", "sources", "sources-registry.json")
    reg = json.load(open(reg_path, encoding="utf-8"))
    targets = [r for r in reg if r.get("decision") in ("ACQUIRE", "ACQUIRE_NOTE")
               and r.get("archive_id") and not r.get("acquired_files")]
    if not targets:
        targets = [r for r in reg if r.get("decision") in ("ACQUIRE", "ACQUIRE_NOTE") and r.get("archive_id")]
    print(f"fetching {len(targets)} sources from archive.org (skipping CATALOG_ONLY/DEFER)...")
    for rec in targets:
        ident, sid = rec["archive_id"], rec["source_id"]
        outdir = os.path.join(here, "..", "raw", sid)
        os.makedirs(outdir, exist_ok=True)
        try:
            d = get(f"https://archive.org/metadata/{ident}")
        except Exception as e:
            print(f"[ERR] {sid}: {str(e)[:60]}"); continue
        files = d.get("files", [])
        got = []
        djvu = [f["name"] for f in files if f["name"].endswith("_djvu.txt")]
        if djvu:
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(djvu[0]),
                             os.path.join(outdir, djvu[0]))
            if st == "ok": got.append(djvu[0])
        pdfs = [f for f in files if f["name"].lower().endswith(".pdf")]
        pdf = None
        for p in sorted(pdfs, key=lambda p: -fsize(p)):
            if fsize(p) <= MAX_MB * (1 << 20): pdf = p; break
        if pdf:
            n, st = download(BASE + urllib.parse.quote(ident) + "/" + urllib.parse.quote(pdf["name"]),
                             os.path.join(outdir, pdf["name"]))
            if st == "ok": got.append(pdf["name"])
        print(f"[{'OK' if got else 'SKIP'}] {sid:42} files={len(got)}")
        time.sleep(0.3)
    print("\ndone. run scripts/processing/process_pass1.py to build texts/ and chunks/.")

if __name__ == "__main__":
    main()
