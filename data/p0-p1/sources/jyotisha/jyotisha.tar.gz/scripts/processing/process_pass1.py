#!/usr/bin/env python3
"""Processing pass 1: raw -> clean text -> semantic chunks.
- djvu.txt present: use as text layer (OCR or native, record which).
- else: extract from PDF with pymupdf (record native vs scanned).
Output: texts/<sid>/full.txt (normalized), chunks/<sid>.jsonl (chapter/verse-level chunks),
plus a processing log line per source."""
import json, os, re, sys, hashlib

def clean_text(raw):
    """Normalize: fix line joins, drop page headers/footers noise, collapse blanks."""
    t = raw.replace("\r\n", "\n").replace("\r", "\n")
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()

def find_chapters(text, max_chunks=400):
    """Split on chapter markers (CH./Chapter/ADHYAYA/अध्याय patterns) where possible; else fixed-size chunks."""
    lines = text.split("\n")
    markers = []
    pat = re.compile(r"^\s*(?:CHAPTER|CH\.|CHAP\.|ADHYAYA|ADHYAYA\s*[-–—]|अध्याय|अध्या\.?)\s*([IVXLCDM\d]+|[-–—]?\s*\d+)\b", re.I)
    for i, ln in enumerate(lines):
        if pat.match(ln):
            markers.append((i, ln.strip()[:60]))
    if len(markers) >= 3:
        chunks = []
        for j, (i, m) in enumerate(markers):
            end = markers[j + 1][0] if j + 1 < len(markers) else len(lines)
            body = "\n".join(lines[i:end]).strip()
            if body:
                chunks.append({"marker": m, "text": body})
        return chunks
    # fallback: fixed-size
    size = 6000
    return [{"marker": f"chunk-{k}", "text": "\n".join(lines[k:k+size])}
            for k in range(0, len(lines), size)][:max_chunks]

def main():
    registry = json.load(open("sources/sources-registry.json", encoding="utf-8"))
    log = []
    for rec in registry:
        sid = rec["source_id"]
        if rec.get("decision") not in ("ACQUIRE", "ACQUIRE_NOTE"):
            continue
        outdir = os.path.join("texts", sid)
        os.makedirs(outdir, exist_ok=True)
        rawdir = os.path.join("raw", sid)
        entry = {"source_id": sid, "status": "", "method": "", "chapters": 0, "chars": 0}
        try:
            text = None
            method = None
            tf = rec.get("text_file")
            if tf and os.path.exists(os.path.join(rawdir, tf)):
                with open(os.path.join(rawdir, tf), encoding="utf-8", errors="replace") as f:
                    text = f.read()
                method = "djvu_txt"
            if text is None or len(text) < 500:
                pf = rec.get("pdf_file")
                if pf and os.path.exists(os.path.join(rawdir, pf)):
                    import pymupdf
                    doc = pymupdf.open(os.path.join(rawdir, pf))
                    text = "\n".join(p.get_text() for p in doc)
                    method = "pymupdf_pdf"
            if text is None or len(text) < 500:
                entry["status"] = "NO_TEXT"; log.append(entry)
                print(f"[NO_TEXT  ] {sid}"); continue
            ct = clean_text(text)
            with open(os.path.join(outdir, "full.txt"), "w", encoding="utf-8") as f:
                f.write(ct)
            chunks = find_chapters(ct)
            with open(os.path.join("chunks", f"{sid}.jsonl"), "w", encoding="utf-8") as f:
                for k, ch in enumerate(chunks):
                    cid = f"{sid}-ch{k+1:04d}"
                    f.write(json.dumps({
                        "chunk_id": cid, "source_id": sid, "index": k,
                        "marker": ch["marker"], "text": ch["text"][:20000],
                        "char_count": len(ch["text"]),
                    }, ensure_ascii=False) + "\n")
            entry.update({"status": "OK", "method": method, "chapters": len(chunks), "chars": len(ct)})
            print(f"[OK       ] {sid:36} {method:12} chapters={len(chunks):4} chars={len(ct):>8}")
        except Exception as e:
            entry["status"] = f"ERROR: {str(e)[:80]}"
            print(f"[ERROR    ] {sid:36} {str(e)[:70]}")
        log.append(entry)
    with open("logs/processing-pass1.json", "w", encoding="utf-8") as f:
        json.dump(log, f, indent=1)

if __name__ == "__main__":
    main()
