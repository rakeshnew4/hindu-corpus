#!/usr/bin/env python3
"""Compute Varshaphala (Tajika solar return) charts with Swiss Ephemeris (Lahiri).
1. Verify: reproduce the 2025-26 annual chart from the PDF (2 Oct 2025 4:35:55 IST).
2. Compute the 2026-27 solar return + all planets + lagna + Muntha.
3. Test dasha-period rules against the PDF's 2025-26 table."""
import swisseph as swe
import datetime as dt
import math

swe.set_sid_mode(swe.SIDM_LAHIRI)
FL = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED
LAT, LON, TZ = 30.7333, 76.7794, 5.5  # Chandigarh

NATAL = {
    "Sun": 164.8106, "Moon": 191.2411, "Mars": 184.2989, "Mercury": 175.6653,
    "Jupiter": 259.4603, "Venus": 195.1572, "Saturn": 141.3331, "Rahu": 291.8150,
}

def ut_from_ist(y, mo, d, hh, mm, ss):
    return dt.datetime(y, mo, d, hh, mm, ss) - dt.timedelta(hours=TZ)

def jd_of(y, mo, d, hh, mm, ss):
    return swe.julday(y, mo, d, hh + mm/60 + ss/3600 - TZ/24)

def positions(jd):
    out = {}
    for name, pid in [("Sun", swe.SUN), ("Moon", swe.MOON), ("Mars", swe.MARS),
                      ("Mercury", swe.MERCURY), ("Jupiter", swe.JUPITER),
                      ("Venus", swe.VENUS), ("Saturn", swe.SATURN)]:
        p, _ = swe.calc_ut(jd, pid, FL)
        out[name] = p[0]
    n, _ = swe.calc_ut(jd, swe.MEAN_NODE, FL)
    out["Rahu"] = n[0]; out["Ketu"] = (n[0] + 180) % 360
    h, _ = swe.houses_ex(jd, LAT, LON, b"P", FL)
    out["Asc"] = h[0]
    return out

def find_solar_return(year, target_lon, guess):
    """Find Sun crossing target_lon (sidereal) near guess. Bisection after sign-change scan."""
    jd0 = swe.julday(guess.year, guess.month, guess.day, guess.hour + guess.minute / 60 - TZ / 24)
    step = 1.0 / 24.0
    # scan backward 5 days, forward 5 days, in 30-min steps, find sign change
    start = jd0 - 5 * 24 * step
    prev_p = None
    cross_jd = None
    for i in range(int(10 * 24 * 2)):
        jd = start + i * step / 2
        p, _ = swe.calc_ut(jd, swe.SUN, FL)
        if prev_p is not None:
            if (prev_p <= target_lon < p[0]) or (p[0] <= target_lon < prev_p):
                cross_jd = jd - step / 2
                break
        prev_p = p[0]
    if cross_jd is None:
        raise RuntimeError("solar return not found in window")
    # bisect to 1 second
    lo, hi = cross_jd, cross_jd + step / 2
    for _ in range(20):
        mid = (lo + hi) / 2
        p, _ = swe.calc_ut(mid, swe.SUN, FL)
        if p[0] <= target_lon:
            lo = mid
        else:
            hi = mid
    p, _ = swe.calc_ut(lo, swe.SUN, FL)
    return lo, p[0]

def jd_to_ist(jd):
    y, mo, d, h = swe.revjul(jd + TZ/24)
    hh = int(h); mm = int((h - hh) * 60); ss = int(((h - hh) * 60 - mm) * 60)
    return f"{d:02d}/{mo:02d}/{y} {hh:02d}:{mm:02d}:{ss:02d} IST"

def sign_of(lon):
    return int(lon // 30)

SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra",
         "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]

print("=== VERIFY 2025-26 annual chart (PDF: 2/10/2025 4:35:55 IST, Leo lagna) ===")
jd25 = jd_of(2025, 10, 2, 4, 35, 55)
p25 = positions(jd25)
for k, v in p25.items():
    print(f"  {k:8} {SIGNS[sign_of(v)]:11} {v % 30:6.2f}  (abs {v:7.2f})")

print("\n=== SOLAR RETURN 2026 (Sun returns to natal 164.8106) ===")
jd26, sun26 = find_solar_return(2026, NATAL["Sun"], dt.datetime(2026, 10, 2, 6, 0))
print("  SR moment:", jd_to_ist(jd26), f"(Sun {sun26:.3f})")
p26 = positions(jd26)
for k, v in p26.items():
    print(f"  {k:8} {SIGNS[sign_of(v)]:11} {v % 30:6.2f}  (abs {v:7.2f})")

# Muntha: age at SR = completed years; 2026-27 = 18th year -> natal lagna + 18 signs
muntha26 = (sign_of(p25["Asc"]) if False else 0 + 18) % 12  # natal lagna Aries = 0
muntha25 = (0 + 17) % 12
print(f"\n  Muntha 2025-26: {SIGNS[muntha25]} (PDF said 2nd bhav of Leo lagna = Virgo) -> {'OK' if SIGNS[muntha25]=='Virgo' else 'MISMATCH'}")
print(f"  Muntha 2026-27: {SIGNS[muntha26]}")

# dasha rule test: PDF periods (days) for 2025-26
pdf_periods = {"Mars": 21, "Rahu": 55, "Jupiter": 48, "Saturn": 58, "Mercury": 52,
               "Ketu": 21, "Venus": 61, "Sun": 18, "Moon": 31}
print("\n=== DASHA RULE TEST (2025-26 SR chart vs PDF periods) ===")
lagna25 = p25["Asc"]
print(f"  SR lagna 2025: {SIGNS[sign_of(lagna25)]} {lagna25 % 30:.2f}")
hypotheses = {
    "lon/360*365": lambda lon, lag: lon / 360 * 365,
    "(lon-lag)%360/360*365": lambda lon, lag: (lon - lag) % 360 / 360 * 365,
    "(lon-sun)%360/360*365": lambda lon, lag: (lon - p25["Sun"]) % 360 / 360 * 365,
    "deg_in_sign*365/360": lambda lon, lag: (lon % 30) / 360 * 365,
    "sign_no(lon)*30+deg /360*365": lambda lon, lag: (sign_of(lon) * 30 + lon % 30) / 360 * 365,
}
for hname, fn in hypotheses.items():
    errs = []
    for pl, days in pdf_periods.items():
        pred = fn(p25[pl], lagna25)
        errs.append(abs(pred - days) / max(days, 1))
    print(f"  {hname:32} mean_rel_err = {sum(errs)/len(errs):.3f}  max = {max(errs):.3f}")

# also try: order by house from lagna + period by degree-in-house... print actual houses
print("\n  SR 2025 houses (whole sign from lagna):")
for pl in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
    house = (sign_of(p25[pl]) - sign_of(lagna25)) % 12 + 1
    print(f"    {pl:8} house {house}  deg_in_sign {p25[pl] % 30:5.2f}")
