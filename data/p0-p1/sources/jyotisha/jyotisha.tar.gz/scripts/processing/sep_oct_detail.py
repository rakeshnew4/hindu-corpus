#!/usr/bin/env python3
"""Full-precision timing for Sep-Oct 2026, tailored to Rishul's chart."""
import swisseph as swe
import datetime as dt
import json

swe.set_sid_mode(swe.SIDM_LAHIRI)
FL = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED
LAT, LON, TZ = 30.7333, 76.7794, 5.5
SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio",
         "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
NAKSH = ["Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra","Punarvasu","Pushya","Ashlesha",
         "Magha","Purva Phalguni","Uttara Phalguni","Hasta","Chitra","Swati","Vishakha","Anuradha",
         "Jyeshtha","Mula","Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha",
         "Purva Bhadrapada","Uttara Bhadrapada","Revati"]

def jd_of(d, hh=12):
    return swe.julday(d.year, d.month, d.day, hh - TZ / 24)

def ist(jd):
    y, mo, d, h = swe.revjul(jd + TZ / 24)
    return f"{d:02d} {mo:02d} {y} {int(h):02d}:{int((h % 1) * 60):02d}"

def lon_at(jd, body):
    p, _ = swe.calc_ut(jd, body, FL)
    return p[0]

def find_cross(start_jd, body, target_sign_idx, days=40):
    """Find when body enters given sign."""
    prev = None
    for i in range(int(days * 24)):
        jd = start_jd + i / 24
        s = int(lon_at(jd, body) // 30)
        if prev is not None and s != prev and s == target_sign_idx:
            return jd
        prev = s
    return None

def find_moon_conj(start_jd, target_lon, days=70, tol=2.0):
    """First date Moon within tol degrees of target longitude."""
    for i in range(int(days * 24)):
        jd = start_jd + i / 24
        m = lon_at(jd, swe.MOON)
        diff = abs((m - target_lon + 180) % 360 - 180)
        if diff < tol:
            return jd
    return None

NATAL = {"Sun": 164.81, "Moon": 191.24, "Mars": 184.30, "Mercury": 175.67,
         "Jupiter": 259.46, "Venus": 195.16, "Saturn": 141.33, "Rahu": 291.81, "Ketu": 111.81}

print("=== SIGN ENTRIES (Sep-Oct 2026) ===")
start = jd_of(dt.datetime(2026, 8, 25))
for body, name in [(swe.SUN, "Sun"), (swe.MERCURY, "Mercury"), (swe.VENUS, "Venus"),
                   (swe.MARS, "Mars"), (swe.JUPITER, "Jupiter")]:
    # find all sign changes in window
    prev = None
    jd = start
    changes = []
    for i in range(int(80 * 24)):
        s = int(lon_at(jd + i / 24, body) // 30)
        if prev is not None and s != prev:
            changes.append((ist(jd + i / 24), SIGNS[s]))
        prev = s
    print(f"  {name:8}: " + "; ".join(f"{d} -> {s}" for d, s in changes))

print("\n=== VENUS STATIONS ===")
start = jd_of(dt.datetime(2026, 9, 1))
prev = None
for i in range(int(90 * 24)):
    jd = start + i / 24
    p, _ = swe.calc_ut(jd, swe.VENUS, FL)
    if prev is not None and (prev < 0) != (p[3] < 0):
        print(f"  Venus station {ist(jd)} speed {p[3]:+.3f} at {SIGNS[int(p[0]//30)]} {p[0]%30:.2f}")
    prev = p[3]

print("\n=== NATAL VENUS CROSSING (Venus return) ===")
jd = find_moon_conj(jd_of(dt.datetime(2026, 10, 20)), NATAL["Venus"], days=75)
if jd: print(f"  Venus at natal Venus (Libra 15.09): ~{ist(jd)} (transit {lon_at(jd, swe.VENUS):.2f})")

print("\n=== NEW MOON / FULL MOON (Sep-Oct 2026) ===")
start = jd_of(dt.datetime(2026, 8, 25))
jd = start
for i in range(int(80 * 24)):
    jd = start + i / 24
    s1, s2 = lon_at(jd, swe.SUN), lon_at(jd, swe.MOON)
    diff = abs((s2 - s1 + 180) % 360 - 180)
    if diff < 1.0:
        kind = "New Moon" if diff < 3 else "Full Moon"
        print(f"  ~{ist(jd)} {kind}: Sun {SIGNS[int(s1//30)]} {s1%30:.1f}, Moon {SIGNS[int(s2//30)]} {s2%30:.1f}")
        # skip ahead
    # crude dedup: only print when near exact

print("\n=== MOON IN SWATI (monthly nakshatra return) ===")
start = jd_of(dt.datetime(2026, 9, 1))
jd = start
swati_start = 15 * 13.3333  # Swati starts at Libra 0 (180 + 13.3333*0)? compute from natal: Swati 2 = Moon's nakshatra
# Swati spans 180.0 - 193.3333 (Libra 0 to Libra 13.3333)
for i in range(int(65 * 24)):
    jd = start + i / 24
    m = lon_at(jd, swe.MOON)
    if 180.0 <= m < 193.3333:
        if not (i > 0 and 180.0 <= lon_at(jd - 1/24, swe.MOON) < 193.3333):
            print(f"  Moon enters Swati ~{ist(jd)}")
    if i > 0:
        m0 = lon_at(jd - 1/24, swe.MOON)
        if 180.0 <= m0 < 193.3333 and not (180.0 <= m < 193.3333):
            print(f"  Moon leaves Swati ~{ist(jd)}")

print("\n=== MOON CONJUNCTIONS WITH NATAL PLANETS (Sep 1 - Oct 31) ===")
start = jd_of(dt.datetime(2026, 9, 1))
for name, tlon in NATAL.items():
    jd = find_moon_conj(start, tlon, days=62)
    if jd:
        print(f"  Moon ~ natal {name} ({SIGNS[int(tlon//30)]} {tlon%30:.1f}): {ist(jd)}")

print("\n=== LUNAR ECLIPSE CHECK (Aug-Sep 2026) ===")
start = jd_of(dt.datetime(2026, 8, 20))
for i in range(int(40 * 24)):
    jd = start + i / 24
    s1, s2 = lon_at(jd, swe.SUN), lon_at(jd, swe.MOON)
    diff = abs((s2 - s1 + 180) % 360 - 180)
    if diff < 0.5:
        # check if near node
        n, _ = swe.calc_ut(jd, swe.MEAN_NODE, FL)
        ndiff = abs((s2 - n + 180) % 360 - 180)
        if ndiff < 12:
            print(f"  ~{ist(jd)}: {'Full' if diff<3 else 'New'} Moon Sun {SIGNS[int(s1//30)]} {s1%30:.1f} Moon {SIGNS[int(s2//30)]} {s2%30:.1f} node-dist {ndiff:.1f}")

print("\n=== SATURN DIRECT ===")
start = jd_of(dt.datetime(2026, 11, 1))
prev = None
for i in range(int(40 * 24)):
    jd = start + i / 24
    p, _ = swe.calc_ut(jd, swe.SATURN, FL)
    if prev is not None and prev < 0 and p[3] >= 0:
        print(f"  Saturn direct ~{ist(jd)} at {SIGNS[int(p[0]//30)]} {p[0]%30:.2f}")
        break
    prev = p[3]
