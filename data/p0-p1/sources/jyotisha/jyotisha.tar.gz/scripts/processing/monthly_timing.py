#!/usr/bin/env python3
"""Compute month-level timing for Rishul: Vimshottari PD boundaries within Jupiter MD
and monthly transit positions Sep-Dec 2026 (Swiss Ephemeris, Lahiri)."""
import swisseph as swe
import datetime as dt
import json

swe.set_sid_mode(swe.SIDM_LAHIRI)
FL = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED
LAT, LON, TZ = 30.7333, 76.7794, 5.5

def jd_of(y, mo, d, hh=12):
    return swe.julday(y, mo, d, hh - TZ / 24)

def dplus(d, days):
    return d + dt.timedelta(days=days)

def fmt(d):
    return d.strftime("%d %b %Y")

# ---- Vimshottari: Jupiter MD 16y from 28/7/2020 ----
MD_START = dt.datetime(2020, 7, 28)
ORDER = [("Jupiter", 16), ("Saturn", 19), ("Mercury", 17), ("Ketu", 7), ("Venus", 20),
         ("Sun", 6), ("Moon", 10), ("Mars", 7), ("Rahu", 18)]

def bounds(md_len_y, ad_frac_y, start):
    """Return list of (pd_name, start_date) for a mahadasha-antardasha."""
    out = []
    d = start
    total_days = ad_frac_y * 365.25
    for name, y in ORDER:
        days = total_days * y / 120.0
        out.append((name, d))
        d = dplus(d, days)
    return out

# AD boundaries in Jupiter MD
ad_start = MD_START
ads = []
for name, y in ORDER:
    days = 16 * y / 120.0 * 365.25
    ads.append((name, ad_start))
    ad_start = dplus(ad_start, days)

print("=== ANTARDASHAS in Jupiter MD (28/7/2020 - 28/7/2036) ===")
for name, d in ads:
    print(f"  {name:8} {fmt(d)}")

# Mercury AD boundaries
mer_ad = [x for x in ads if x[0] == "Mercury"][0][1]
print(f"\n=== PRATYANTARDASHAS in Jupiter-Mercury (from {fmt(mer_ad)}) ===")
pds = bounds(16, 17, mer_ad)
for name, d in pds:
    print(f"  Mer-{name:8} {fmt(d)}")

# ---- Monthly transits Sep-Dec 2026 (15th of each month, noon IST) ----
print("\n=== TRANSITS (15th of month, noon IST) ===")
bodies = [("Sun", swe.SUN), ("Moon", swe.MOON), ("Mars", swe.MARS), ("Mercury", swe.MERCURY),
          ("Jupiter", swe.JUPITER), ("Venus", swe.VENUS), ("Saturn", swe.SATURN)]
SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio",
         "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
for mo in [9, 10, 11, 12]:
    jd = jd_of(2026, mo, 15)
    row = {}
    for name, pid in bodies:
        p, _ = swe.calc_ut(jd, pid, FL)
        row[name] = {"sign": SIGNS[int(p[0] // 30)], "deg": round(p[0] % 30, 2),
                     "retro": bool(p[3] < 0) if pid not in (swe.SUN, swe.MOON) else False}
    n, _ = swe.calc_ut(jd, swe.MEAN_NODE, FL)
    row["Rahu"] = {"sign": SIGNS[int(n[0] // 30)], "deg": round(n[0] % 30, 2), "retro": True}
    row["Ketu"] = {"sign": SIGNS[int((n[0] + 180) % 360 // 30)], "deg": round((n[0] + 180) % 30, 2), "retro": True}
    print(f"  {mo:02d}/2026: " + " | ".join(f"{k} {v['sign'][:4]} {v['deg']}{'R' if v['retro'] else ''}" for k, v in row.items()))

# ---- Jupiter station dates: find retro->direct and direct->retro around Oct 2026 ----
def jup_sign_and_speed(jd):
    p, _ = swe.calc_ut(jd, swe.JUPITER, FL)
    return p[0], p[3]

print("\n=== JUPITER STATIONS (2026) ===")
# scan Sep 2026 - Mar 2027 for speed sign changes
start = jd_of(2026, 9, 1)
prev_spd = None
for i in range(200):
    jd = start + i
    p, _ = swe.calc_ut(jd, swe.JUPITER, FL)
    spd = p[3]
    if prev_spd is not None and (prev_spd < 0) != (spd < 0):
        y, mo, d, h = swe.revjul(jd + TZ / 24)
        print(f"  Jupiter station ~ {d:02d}/{mo:02d}/{y} speed {prev_spd:+.3f} -> {spd:+.3f} (sign {SIGNS[int(p[0]//30)]})")
    prev_spd = spd
# Jupiter sign crossings Sep 2026 - Mar 2027
prev_sign = None
for i in range(200):
    jd = start + i
    p, _ = swe.calc_ut(jd, swe.JUPITER, FL)
    s = int(p[0] // 30)
    if prev_sign is not None and s != prev_sign:
        y, mo, d, h = swe.revjul(jd + TZ / 24)
        print(f"  Jupiter enters {SIGNS[s]} ~ {d:02d}/{mo:02d}/{y}")
    prev_sign = s

# Saturn: where is it moving? sign + next crossing
p, _ = swe.calc_ut(jd_of(2026, 12, 31), swe.SATURN, FL)
print(f"\nSaturn on 31/12/2026: {SIGNS[int(p[0]//30)]} {round(p[0]%30,2)}")
start = jd_of(2026, 12, 31)
for i in range(140):
    jd = start + i
    p, _ = swe.calc_ut(jd, swe.SATURN, FL)
    if int(p[0] // 30) != int(swe.calc_ut(jd_of(2026,12,31), swe.SATURN, FL)[0][0] // 30):
        y, mo, d, h = swe.revjul(jd + TZ / 24)
        print(f"Saturn enters {SIGNS[int(p[0]//30)]} ~ {d:02d}/{mo:02d}/{y}")
        break
