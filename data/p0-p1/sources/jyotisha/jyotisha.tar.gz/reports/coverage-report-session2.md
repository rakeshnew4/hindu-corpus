# Jyotisha Corpus — Coverage Report (Session 2, 2026-08-31)

_Session 1 report: `reports/coverage-report-session1.md`. This supersedes its numbers._

## Coverage statement
**58 sources acquired** (29.8M chars clean text, 1,099 chunks), **75 registry records** total
(17 catalogued-without-acquisition). Source families now: archive.org public scans (49),
sanskritdocuments.org machine-readable Sanskrit (15), GitHub software (7 repos cloned).
This is a **substantial but still open-ended** corpus: Tajika, Prashna (horary), Nadi,
and academic layers remain thin.

## Metrics
| Metric | Value |
|---|---|
| Registry records | 75 |
| Acquired with files | 58 |
| Clean text | 29,778,418 chars |
| Semantic chunks | 1,099 |
| Extracted rules | **199** (all verbatim-anchored to source text; 60 Brihat Jataka, 60 Jataka Parijata, 59 Brihat Samhita, 20 Phaladeepika) |
| Software repos cloned | 7 |
| Quality mix (acquired) | 18 OK_ENGLISH, 19 DEVANAGARI, 5 MIXED, 15 ITX_TRANSLITERATED, 1 RAW_ONLY |
| Catalog-only (copyright/rights) | 17 |
| Excluded (illicit) | 1 (cracked Parashara Light) |
| Wrong-work caught | 2 (Purva Mimamsa as 'Jaimini Sutras'; Milind Prashna as horary) |
| Metadata stubs (no files) | 10 eGangotri items + 2 |

## What pass 2 added (the big items)
- **Sanskrit BPHS** — full 11-part machine-readable text (436K chars, ITRANS) from sanskritdocuments.org + 2009 Sanskrit print scan (1.1M chars)
- **BPHS commentary layer**: Sudha (KSS 220, 1.18M chars), Subodhini (catalog-only, stub)
- **Brihat Samhita editions**: Kern 1865 (Sanskrit, scholarly), Iyer 1885 w/ appendix, Sastri 1946, Mishra 1948 Hindi tika, Venkateshwar 1933, DLI 1959, Vimala commentary vols 1-2 (Bhattotpala), Baldev Prasad Hindi
- **Astronomy/math**: Panchasiddhantika ×3 (1882, Dvivedi 1889, Thibaut 1889), Surya Siddhanta ×3
- **Classical jataka**: Bhattotpala Vivrutti on Brihat Jataka, Jataka Tattva (Sastri), Uttara Kalamrita (Sastri 1937), Laghu Jataka, Jataka Parijata Sanskrit (SD), Brihat Jataka Sanskrit (SD), Phaladeepika Sanskrit (SD), Laghu Parashari Hindi, Saravali Sanskrit, Shatpanchasika ×3, Garga Hora, Chamatkar Chintamani (SD), Daivajnavallabha (SD), Vriddha Yavana Jataka (SD + Devanagari stub)
- **Ashtakavarga** (Patel & Aiyar 1957, 134 chunks), **Bhrigu Sanhita Paddhati 1949**, **Bhrigu Sutram** (SD), **Muhurta Chintamani** (Hindi KDJ + Sanskrit Piyusha Dhara stub), **Nadi Jyothisha 1931**, **Deva Keralam 1992**, **Tithi Chintamani** (stub), **Ramagya Prashna** (stub)
- **Vedanga**: Yajush Jyotisha, Archa Jyotisha

## Legal posture
- 7 explicit public domain (pre-1929) + all pre-1929 editions acquired as ACQUIRE
- ~40 `PD_IN_INDIA_LIKELY` (pre-1960 Indian publications / ancient texts in old prints) — audit task: verify translator/commentator death dates
- 15 sanskritdocuments.org texts: `OPEN_SITE_PERSONAL_RESEARCH` (volunteer-prepared, stated use = personal study/research)
- 17 catalog-only: Santhanam BPHS + Hora Ratnam, Raman works, R.G. Rao Nadi, Sanjay Rath, Charak, modern Hindi editions w/ unknown imprints, Dvivedi 1996 critical ed., compiled English BPHS ebook, 10 file-less eGangotri stubs

## School coverage
| School | Status |
|---|---|
| Parashari | ✓✓ (BPHS Sanskrit + 2 commentaries + 4 major phalita texts + Saravali + Tattva + Kalamrita) |
| Jaimini | ◐ (Jaimini Sutras 1949, mixed OCR) |
| Nadi | ◐ (Nadi Jyothisha 1931, Deva Keralam; modern Rao works catalog-only) |
| Bhrigu | ◐ (Sanhita Paddhati 1949, Sutram SD; Nandi Nadi catalog-only) |
| Tajika | ✗ |
| Prashna | ◐ (Ramagya Prashna stub; nothing acquired yet) |
| Muhurta | ✓ (Chintamani Hindi + Sanskrit commentary layers) |
| Astronomy | ✓✓ (Panchasiddhantika ×3, Surya Siddhanta ×3, Yajush/Archa) |
| Ashtakavarga | ✓ (Patel & Aiyar 1957) |
| Software | ✓ (7 repos: jyotisham, VedAstro.Py, PyJHora, kunjara, drik-panchanga, xalen, VedicAstro) |

## Remaining gaps (pass 3)
1. **Tajika family** (Tajika Neelakanthi, Varshaphala) — zero coverage
2. **Prashna Marga / Prashna Tantra** — acquire real scans
3. Re-OCR the 5 MIXED texts with Devanagari-capable OCR
4. Academic layer (Shodhganga/arXiv history of Jyotisha papers)
5. Rule-extraction continuation: Jataka Parijata Sanskrit, Ashtakavarga, BPHS Sanskrit (via translation)
6. Vector index (embeddings) for semantic retrieval
7. Case studies (documented charts)
