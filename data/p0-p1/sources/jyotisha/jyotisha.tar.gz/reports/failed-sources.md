# Failed / Excluded / Unavailable Source Report

_Updated 2026-08-31 (session 2). Every failure is recorded, per SPEC §35._

## EXCLUDED — illicit material
| Item | Why | Date |
|---|---|---|
| `parasharalight7vedicastrologycrack` (archive.org) | Cracked proprietary software (Parashara Light 6.1) | 2026-08-31 |

## WRONG-WORK (metadata vs content mismatch, caught by content verification)
| Item | Appeared as | Actually is | Action |
|---|---|---|---|
| `in.ernet.dli.2015.274358` | Jaimini Sutras (1916) | Purva Mimamsa Sutras of Jaimini (Mimamsa, not Jyotisha) | EXCLUDED |
| `in.ernet.dli.2015.473674` | Prashna (1937) | Milind Prashna (Buddhist Milindapanha) | EXCLUDED |

## METADATA STUBS — item exists on archive.org but has NO downloadable files (eGangotri-style)
Treated as CATALOG_ONLY; may become acquirable if files appear.
- xpnh_brihat-parashara-hora-shastra-purva-uttar (BPHS Subodhini)
- Vkfo_ / UCCy_ muhurta-chintamani-of-rama-daivajnya-with (×2)
- cfdT_muhurta-chintamani-with-piyush-dhara-comm
- YQsI_bhrigu-sutram-with-hindi-tika-by-pt.-sidd
- jatakachandrikachundrikavenkateshapanditamoonl
- jmoh_7-stri-jataka-vriddha-yavana-devanagari-k
- tithichintamaniofganesadavignadattatreyabalava
- Djxb_ramagya-prashna-of-goswami-tulsi-das-gita
- zwux_graha-laghavam-by-ganesha-daivagya-sanskr
- reoo_brihat-parashara-hora-shastra-subodhini-c (id unresolved)

## LOW-TRUST / JUNK MIRRORS (not used)
- `kupdf.net_uttkalamitra-kalidas-ps-sastri` — kupdf mirror of a printed book; no PDFs on item; prefer direct 1937 scan (already acquired: TXT-uttara-kalamrita-sastri1937)
- `XpDV_jataka-parijata-with-explanation-of-pt.-kapil` — no files
- `saravaliofkalyanavarmasanthanamr.astrology_202003_` — no files + Santhanam (copyright)

## CATALOG-ONLY — legally accessible but in copyright (recorded, not downloaded)
- BPHSEnglish (Santhanam BPHS trans., d. 2005) — note: widely cited; Wikipedia cites it
- Book11.HoraRatnam10NoOCR (Santhanam trans., d. 2005)
- bhrigu-nandi-nadi (R.G. Rao, modern compilation)
- jmbQ / AManualOfHinduAstrology / ThreeHundredImportantCombinations (B.V. Raman, d. 1998)
- HoraSaraRSanthanamEng (Santhanam)
- sanjayrathcruxofvedicastrologytimingofevents (Sanjay Rath 1998)
- KCzD_elements-of-vedic-astrology (Charak)
- muhurtamartandadr.satyendramishra (Mishra, modern)
- dli.ministry.25756 (1967 Kannan)
- bhriguprashnanadiraor.g.astrology (Rao)
- brihat-parashar-hora-sastra (Santhanam-derived scan)
- bhrigu-samhita (Hindi, unknown imprint)
- deva-keralam-1-chandrakala-nadi (Hindi, unknown imprint)
- chamatkar-chintamani-of-bhatta-narayana-pdf (Hindi, unknown imprint)
- chamatkarchintamanibrajbiharilalsharma (B.B.L. Sharma, modern)
- mgos_20190802 (Saptarishi Nadi, Tamil, huge scans)
- lPan_... (K.C. Dwivedi critical ed. 1996)
- ParasharaHoraSastra (compiled English ebook, provenance unknown)
- muhurta-chintamani-hindi (duplicate-ish of acquired Hindi ed.; imprint unknown)

## OCR / TEXT QUALITY DEFERRED
- 5 DEVANAGARI_MIXED texts (jaimini-sutras-rao1949, brihat-jataka-rao1919, phaladeepika-1937a, laghu-parashari-jha1900, laghujataka) — Sanskrit verses readable, English layer mangled → re-OCR with Devanagari-capable model (marker-pdf) in a later pass
- TXT-sanskrit-bundle (12 PDFs, DLI Sanskrit collection) — raw only; djvu OCR garbage → per-file re-OCR needed
