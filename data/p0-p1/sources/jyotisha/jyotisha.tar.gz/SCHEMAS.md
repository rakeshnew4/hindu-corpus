# Jyotisha Corpus — Schemas & Conventions

Governing spec: `SPEC.md` (75 sections). This file codifies the conventions used in this corpus.

## Source IDs
Pattern: `<TYPE>-<SLUG>` where TYPE ∈ {TXT, SW, PAPER, WEB, MS} and SLUG is a short ASCII slug of the work (e.g. `TXT-bphs`, `TXT-brihat-jataka`, `SW-jyotisha`, `PAPER-xxx`).
Every entity (text, author, rule, yoga, dasha, varga, software, paper) gets a stable ID. Rules: `RULE-<TXT-slug>-<nnnnnn>` (zero-padded seq per source).

## Source registry (sources/sources-registry.json)
Array of source records:
```json
{
  "source_id": "TXT-brihat-jataka",
  "title": "Brihat Jataka of Varahamihira",
  "alt_titles": ["Brihatjataka", "बृहज्जातक"],
  "author": "Varahamihira",
  "author_id": "AUTHOR-varahamihira",
  "date": "~550 CE",
  "language": "Sanskrit (trans. English)",
  "school": "Parashari",
  "source_type": "PRIMARY_CLASSICAL_TEXT",
  "edition": "Trans. N. Chidambaram Iyer, 1905",
  "url": "...",
  "archive_id": "...",
  "access_status": "PUBLIC_DOMAIN",
  "license": "Public Domain",
  "file_hash": "sha256:...",
  "acquisition_date": "2026-08-31",
  "acquisition_method": "archive.org download",
  "ocr_status": "NATIVE_TEXT",
  "extraction_status": "EXTRACTED",
  "notes": ""
}
```

## Rule record (data/rules.json)
Per SPEC §24: rule_id, school, source, text_reference (ch/verse/page), condition, modifiers, interpretation, exceptions, timing, confidence {textual, scholarly, cross_source, practitioner}, original_text (Devanagari/IAST/translation), related_rules, contradictions.

## Provenance classification (SOURCE_TYPE)
PRIMARY_CLASSICAL_TEXT | CLASSICAL_COMMENTARY | MEDIEVAL_TEXT | MODERN_BOOK | MODERN_COMMENTARY | ACADEMIC_PAPER | THESIS | WEBSITE | BLOG | FORUM | PRACTITIONER_NOTE | SOFTWARE_DOCUMENTATION | OPEN_SOURCE_CODE | DATASET | VIDEO_TRANSCRIPT | LECTURE | SOCIAL_MEDIA | OTHER

## Layers
- `raw/` — immutable originals (never modified), subdir per source_id, sha256 recorded
- `texts/` — cleaned normalized text, subdir per source_id
- `chunks/` — semantic chunks (chapter/verse/paragraph), JSONL
- `data/` — structured databases (authors, texts, rules, yogas, dashas, vargas, nakshatras, karakas, contradictions, terms, software, academic, case-studies)
- `reports/` — coverage report, quality report, failed-source report
- `logs/` — processing logs (append-only)

## School separation (HARD RULE)
Parashari, Jaimini, Nadi, Bhrigu, Tajika, Prashna, Muhurta are separate namespaces. Never merge contradictory rules (§23, §60). Every rule carries its school.

## No-hallucination (HARD RULE)
Unknown facts are marked UNKNOWN/UNCERTAIN/DISPUTED/TRADITIONALLY_ATTRIBUTED/UNVERIFIED. No fabricated verses, quotes, titles, authors, dates, or formulas.
