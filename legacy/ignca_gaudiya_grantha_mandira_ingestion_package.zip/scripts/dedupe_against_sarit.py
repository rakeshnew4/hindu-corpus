#!/usr/bin/env python3
import argparse,hashlib,json,re
from pathlib import Path
def norm(s): return re.sub(r"[^a-z0-9\\u0900-\\u097f]+","",re.sub(r"\\s+"," ",s.lower()))
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--ignca-text",required=True);ap.add_argument("--sarit-dir",required=True);ap.add_argument("--out",default="metadata/ignca_sarit_dedupe.json");a=ap.parse_args()
 sh={}
 for p in Path(a.sarit_dir).rglob("*.json*"):
  try:
   o=json.loads(p.read_text(encoding="utf-8",errors="ignore")); vals=[]
   def walk(x):
    if isinstance(x,dict):
     for k,v in x.items():
      if k in ("text","text_original","content","translation") and isinstance(v,str):vals.append(v)
      else:walk(v)
    elif isinstance(x,list):
     for v in x:walk(v)
   walk(o);t=norm(" ".join(vals))
   if t:sh[hashlib.sha256(t.encode()).hexdigest()]=str(p)
  except:pass
 m=[]
 for p in Path(a.ignca_text).glob("*.txt"):
  h=hashlib.sha256(norm(p.read_text(encoding="utf-8",errors="ignore")).encode()).hexdigest()
  if h in sh:m.append({"ignca":str(p),"sarit":sh[h],"type":"exact_normalized_text_hash"})
 Path(a.out).parent.mkdir(parents=True,exist_ok=True);Path(a.out).write_text(json.dumps({"exact_matches":m},indent=2),encoding="utf-8");print("Exact matches:",len(m))
if __name__=="__main__":main()
