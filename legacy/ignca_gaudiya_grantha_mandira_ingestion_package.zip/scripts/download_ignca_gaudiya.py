#!/usr/bin/env python3
import argparse,csv,hashlib,json,re,time
from datetime import datetime,timezone
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin,unquote
CATALOG="https://ignca.gov.in/online-digital-resources/gaudiya-grantha-mandira-sanskrit-text-repository/"
UA="Whole-System-RAG/1.0"
def sha256(p):
 h=hashlib.sha256()
 with open(p,"rb") as f:
  for b in iter(lambda:f.read(1024*1024),b): h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--out",default="ignca_gaudiya")
 ap.add_argument("--extract-text",action="store_true")
 ap.add_argument("--delay",type=float,default=.2)
 a=ap.parse_args(); root=Path(a.out); pdf=root/"pdf"; txt=root/"text"; meta=root/"metadata"
 pdf.mkdir(parents=True,exist_ok=True); txt.mkdir(exist_ok=True); meta.mkdir(exist_ok=True)
 r=requests.get(CATALOG,headers={"User-Agent":UA},timeout=60); r.raise_for_status()
 html=r.text; (meta/"catalog.html").write_text(html,encoding="utf-8")
 soup=BeautifulSoup(html,"html.parser"); items=[]
 for x in soup.find_all("a",href=True):
  u=urljoin(CATALOG,x["href"])
  if not u.lower().endswith(".pdf"): continue
  tr=x.find_parent("tr"); cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])] if tr else []
  items.append({"title":x.get_text(" ",strip=True),"filename":unquote(u.rsplit("/",1)[-1]),"url":u,"catalog_cells":cells})
 seen=set(); items=[x for x in items if not (x["url"] in seen or seen.add(x["url"]))]
 manifest=[]; now=datetime.now(timezone.utc).isoformat()
 for i,it in enumerate(items,1):
  p=pdf/Path(it["filename"]).name; status="downloaded"; err=""
  try:
   if not p.exists():
    with requests.get(it["url"],headers={"User-Agent":UA},stream=True,timeout=120) as q:
     q.raise_for_status()
     with open(p,"wb") as f:
      for b in q.iter_content(1024*1024):
       if b:f.write(b)
    time.sleep(a.delay)
  except Exception as e: status="error";err=str(e)
  rec=dict(it,index=i,retrieved_at=now,status=status,error=err)
  if p.exists():
   rec.update(sha256=sha256(p),bytes=p.stat().st_size)
   if a.extract_text:
    import subprocess
    out=txt/(p.stem+".txt")
    try: subprocess.run(["pdftotext","-layout",str(p),str(out)],check=True); rec["text_file"]=str(out.relative_to(root))
    except Exception as e: rec["text_error"]=str(e)
  manifest.append(rec); print(f"[{i}/{len(items)}] {status} {p.name}")
 (meta/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
 with open(meta/"manifest.csv","w",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fieldnames=["index","title","filename","url","retrieved_at","status","error","sha256","bytes"]);w.writeheader()
  for r in manifest:w.writerow({k:r.get(k,"") for k in w.fieldnames})
 print("PDF links:",len(items),"downloaded:",sum(x["status"]=="downloaded" for x in manifest),"errors:",sum(x["status"]=="error" for x in manifest))
if __name__=="__main__":main()
