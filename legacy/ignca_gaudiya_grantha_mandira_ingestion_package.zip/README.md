# IGNCA Gaudiya Grantha Mandira ingestion package

Source:
https://ignca.gov.in/online-digital-resources/gaudiya-grantha-mandira-sanskrit-text-repository/

IGNCA currently describes this repository as a catalogue of Sanskrit texts in PDF format, with over 13,000 pages; the catalogue shows a total size of about 97.4 MB.

This package contains a reproducible downloader because the execution environment used to prepare this package could inspect the IGNCA catalogue and PDFs through web retrieval, but could not directly persist the remote PDF binaries into the working filesystem.

The downloader:
1. Fetches the IGNCA catalogue.
2. Extracts every PDF link.
3. Downloads each PDF.
4. Records title/category/filename/page/size/url/retrieval date/SHA-256.
5. Optionally extracts text.
6. Compares normalized text hashes against an existing SARIT corpus.
7. Produces a deduplicated RAG-ready directory while retaining all source originals.

IMPORTANT:
- Do not assume every IGNCA item is absent from SARIT.
- Some works clearly overlap with broader Sanskrit corpora (for example Bhagavad Gita, Yoga Sutra, Hatha Yoga Pradipika, Upanishadic material).
- IGNCA is especially valuable for its commentary editions and Gaudiya-specific materials.
- Keep source provenance and licensing information with every document.
