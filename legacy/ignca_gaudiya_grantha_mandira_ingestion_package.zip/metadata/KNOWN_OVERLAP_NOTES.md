# Known overlap with SARIT

The IGNCA catalogue includes works that can also occur in broader Sanskrit corpora, so it should not be blindly appended to the SARIT vector store.

Likely/known overlapping areas include Bhagavad Gita and commentaries, Yoga Sutra, Hatha Yoga Pradipika, Upanishadic texts, and Puranic texts.

IGNCA is also valuable for Gaudiya-specific works and commentary editions. The ingestion pipeline therefore preserves source identity, original PDF SHA-256, normalized-text duplicate checks, provenance, and edition/commentary metadata.

Exact hashes cannot detect OCR/encoding/edition differences, so semantic near-duplicate checking should follow text extraction.
